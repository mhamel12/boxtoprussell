# ===============================================================
# 
# box2html.pl
#
# (c) 2010-2011 Michael Hamel
#
# This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License. To view a copy of this license, visit # http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.
#
# Version history
# 12/28/2010  1.0  MH  Initial version
# 03/11/2011  1.1  MH  Team rebounds in box scores = REB + TEAMREBOUNDS
# 04/02/2011  1.2  MH  Added meta tags, BOXTOP links, and citation info
# 04/23/2011  1.3  MH  Cleanup radio/tv and some other fields
# 05/26/2011  1.4  MH  Support for multiple game note fields and title argument
# 08/21/2011  1.5  MH  Event, Prelim, Note fields can now include commas
#
# ===============================================================


#! usr/bin/perl
use Getopt::Std;

# store data split in these hashes
my %info;

# store data unsplit in these hashes, indexed by hteam and rteam
my %coaches;
my %team_stats;
my %linescores;

# store data unsplit in these hashes, indexed by player id
my %road_player_stats;
my %home_player_stats;

my $sources_note = "";

my $index_count = 1;
my $game_count = 1;

# Team pages on BR.com of the form: http://www.basketball-reference.com/teams/BOS/1957.html
my $BR_team_page_preamble = "http:\/\/www.basketball-reference.com\/teams\/";
%team_page_from_full_name_hash =
(   "Boston Celtics" => "BOS",
    "Philadelphia Warriors" => "PHW",
    "Philadelphia 76ers" => "PHI",
    "New York Knickerbockers" => "NYK",
    "Atlanta Hawks" => "ATL",
    "St. Louis Hawks" => "STL",
    "Minneapolis Lakers" => "MNL",
    "Los Angeles Lakers" => "LAL",
    "Syracuse Nationals" => "SYR",
    "Rochester Royals" => "ROC",
    "Cincinnati Royals" => "CIN",
    "San Francisco Warriors" => "SFW",
    "Fort Wayne Pistons" => "FTW",
    "Detroit Pistons" => "DET",
    "San Diego Rockets" => "SDR",
    "Seattle Supersonics" => "SEA",
    "Milwaukee Bucks" => "MIL",
    "Phoenix Suns" => "PHO",
    "Baltimore Bullets" => "BAL",
    "Chicago Packers" => "CHP",
    "Chicago Zephyrs" => "CHZ",
    "Chicago Bulls" => "CHI",
);

# ===============================================================

sub usage
{
    print "Convert a boxtop-format file into a single html format page.\n\n";
    print "Output includes html tables with dynamic row shading (could cause ActiveX warnings in IE).\n";
    print "\n";
    print "\nUSAGE:\n box2html.pl [-i inputfilename] [-o outputfilename] [-t outputpagetitle]\n";
    print " Default filenames are input.csv and output.html unless specified.\n";
}
# end of sub usage()

# ===============================================================

sub getstring
{
    $string = <>;
    chomp($string); # strip off CR
    return $string;
}
# end of sub getstring()

# ===============================================================
# 
# parse_csv_line()
#
# Parses one line of a csv file and fills an array to return to caller.
#
# Input:
#
# Output:
#  Array that contains each element of the csv line.
#
# ===============================================================
sub parse_csv_line(@)
{
    ($line) = @_;

        # Note: If we don't declare this here, we end up re-using previously
    #       declared variable on our next trip through here!
        my @csv_elements;

        # trick - add a comma at the end of the line in place of the CR
        # makes searching easier...
        chomp($line);
        $line = join(",",$line,"");
    
        while ((my $next_comma = index($line,",")) >= 0)
        {
            # Grab next column header.
            push @csv_elements, substr($line,0,$next_comma);

            $line = substr($line,($next_comma+1),length($line));
        }
    
        return(@csv_elements);
}
# end of sub parse_csv_line()

# ===============================================================

sub add_footer()
{
	($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);

	print output_filehandle "<p>This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License.<br>To view a copy of this license, visit <a href=\"http:\/\/creativecommons.org\/licenses\/by-nc-sa\/3.0\/\">http:\/\/creativecommons.org\/licenses\/by-nc-sa\/3.0\/<\/a>\n";
	printf output_filehandle "<p>Web page created at %02d:%02d:%02d on %02s\/%02d\/%4d using box2html.pl based on <a href=\"http://www.michaelhamel.net/boxtop-project\">boxtop format data<\/a>, (c) 2010-2011 Michael Hamel.\n",$hour,$min,$sec,$mon+1,$mday,$year+1900;
	print output_filehandle "<p>Citation: The information used here was obtained free of charge from and is copyrighted by the <a href=\"http://www.michaelhamel.net/boxtop-project\">Basketball BOXTOP Project<\/a>.\n";

}
# end of sub add_footer()

# ===============================================================

# 1952-1970 stats
# $formatted_stat_line_header = "<tr><td><\/td><td align = \"right\">Min<\/td><td align = \"right\">FGM<\/td><td align = \"right\">FGA<\/td><td align = \"right\">FTM<\/td><td align = \"right\">FTA<\/td><td align = \"right\">REB<\/td><td align = \"right\">AST<\/td><td align = \"right\">PF<\/td><td align = \"right\">PTS<\/td><\/tr>";
$formatted_stat_line_header = "<tr><td><\/td><td align = \"right\" width=20>MIN<\/td><td align = \"right\" width=20>FGM<\/td><td align = \"right\" width=20>FGA<\/td><td align = \"right\" width=20>FTM<\/td><td align = \"right\" width=20>FTA<\/td><td align = \"right\" width=20>REB<\/td><td align = \"right\" width=20>AST<\/td><td align = \"right\" width=20>PF<\/td><td align = \"right\" width=20>PTS<\/td><\/tr>";

$br_player_link = "http:\/\/www.basketball-reference.com\/players";
$br_coach_link = "http:\/\/www.basketball-reference.com\/coaches";

sub dump_data_to_file()
{
#   print(%info);
#   print(%coaches);
#   print(%team_stats);
#   print(%linescores);
#   print(%road_player_stats);
#   print(%home_player_stats);

    print output_filehandle "<a name=Game$game_count><\/a>\n";
    $game_count++;
    print output_filehandle "<h2>$info{rteam} vs. $info{hteam}<\/h2>\n";
    print output_filehandle "<h3>\n$info{title}<br>\n$info{dayofweek} $info{date} at $info{arena}<br>\n$info{city}, $info{state}, $info{country}\n<\/h3>\n";

# head coaches

# stats go here in tables... road on top, home on bottom. Need to have links and fangraph-style shading.

    # start by building the link for the BR.com team page for this team
    # note that we only have to derive the "season_year" once, and use it again for the home team.
    @date_parts = split('/',$info{date});
    $season_year = $date_parts[2];
    if ($date_parts[0] > 6) # game took place after June, so this is the following season (October 1956 game is during "1957" season from BR.com's perspective
    {
        $season_year++;
    }

    $team_with_link = $BR_team_page_preamble . $team_page_from_full_name_hash{$info{rteam}} . "\/" . $season_year . ".html"; 

    print output_filehandle  "<p><h3><a href=$team_with_link>$info{rteam}<\/a><\/h3>";

    print output_filehandle "<table>\n";
    print output_filehandle $formatted_stat_line_header;
    foreach $value (sort values %road_player_stats)
    {
#       print $value;
        @stats_line = parse_csv_line($value);
        $ch = substr($stats_line[3],0,1);
#       print $ch;
        print output_filehandle "<tr onmouseover=\"this.style.backgroundColor = '#CCCCCC';\" onmouseout=\"this.style.backgroundColor = '#f7f6eb';\"><td align = \"left\"><a href=\"$br_player_link\/$ch\/$stats_line[3].html\">$stats_line[4] $stats_line[5]<\/a><\/td><td align = \"right\">$stats_line[6]<\/td><td align = \"right\">$stats_line[7]<\/td><td align = \"right\">$stats_line[8]<\/td><td align = \"right\">$stats_line[9]<\/td><td align = \"right\">$stats_line[10]<\/td><td align = \"right\">$stats_line[15]<\/td><td align = \"right\">$stats_line[16]<\/td><td align = \"right\">$stats_line[17]<\/td><td align = \"right\">$stats_line[13]<\/td><\/tr>\n";
    }
    $value = $team_stats{rteam};
    @stats_line = parse_csv_line($value);

    # Add rebounds + teamrebounds together to match usual boxscore format
    # If no rebounds available, then print a blank
    if ($stats_line[11] ne "")
    {
		$rebounds = $stats_line[11] + $stats_line[17];
	}
	else
	{
		$rebounds = "";
	}
    	
    print output_filehandle "<tr onmouseover=\"this.style.backgroundColor = '#CCCCCC';\" onmouseout=\"this.style.backgroundColor = '#f7f6eb';\"><td align = \"left\"><b>Totals</b><\/td><td align = \"right\"><\/td><td align = \"right\">$stats_line[3]<\/td><td align = \"right\">$stats_line[4]<\/td><td align = \"right\">$stats_line[5]<\/td><td align = \"right\">$stats_line[6]<\/td><td align = \"right\">$rebounds<\/td><td align = \"right\">$stats_line[12]<\/td><td align = \"right\">$stats_line[13]<\/td><td align = \"right\">$stats_line[9]<\/td><\/tr>\n";
    print output_filehandle "<\/table>\n";

    if ($stats_line[17] ne "") { print output_filehandle "<h4>Team Rebounds: $stats_line[17]<\/h4>\n"; }

    # re-use season_year derived above    
    $team_with_link = $BR_team_page_preamble . $team_page_from_full_name_hash{$info{hteam}} . "\/" . $season_year . ".html"; 

    print output_filehandle  "<p><h3><a href=$team_with_link>$info{hteam}<\/a><\/h3>";
    
    print output_filehandle "<table>\n";
    print output_filehandle $formatted_stat_line_header;
    foreach $value (sort values %home_player_stats)
    {
#       print $value;
        @stats_line = parse_csv_line($value);
        $ch = substr($stats_line[3],0,1);
#       print $ch;
        print output_filehandle "<tr onmouseover=\"this.style.backgroundColor = '#CCCCCC';\" onmouseout=\"this.style.backgroundColor = '#f7f6eb';\"><td align = \"left\"><a href=\"$br_player_link\/$ch\/$stats_line[3].html\">$stats_line[4] $stats_line[5]<\/a><\/td><td align = \"right\">$stats_line[6]<\/td><td align = \"right\">$stats_line[7]<\/td><td align = \"right\">$stats_line[8]<\/td><td align = \"right\">$stats_line[9]<\/td><td align = \"right\">$stats_line[10]<\/td><td align = \"right\">$stats_line[15]<\/td><td align = \"right\">$stats_line[16]<\/td><td align = \"right\">$stats_line[17]<\/td><td align = \"right\">$stats_line[13]<\/td><\/tr>\n";
    }
    $value = $team_stats{hteam};
    @stats_line = parse_csv_line($value);

    if ($stats_line[11] ne "")
    {
		$rebounds = $stats_line[11] + $stats_line[17];
	}
	else
	{
		$rebounds = "";
	}

	print output_filehandle "<tr onmouseover=\"this.style.backgroundColor = '#CCCCCC';\" onmouseout=\"this.style.backgroundColor = '#f7f6eb';\"><td align = \"left\"><b>Totals</b><\/td><td align = \"right\"><\/td><td align = \"right\">$stats_line[3]<\/td><td align = \"right\">$stats_line[4]<\/td><td align = \"right\">$stats_line[5]<\/td><td align = \"right\">$stats_line[6]<\/td><td align = \"right\">$rebounds<\/td><td align = \"right\">$stats_line[12]<\/td><td align = \"right\">$stats_line[13]<\/td><td align = \"right\">$stats_line[9]<\/td><\/tr>\n";
    print output_filehandle "<\/table>\n";

    if ($stats_line[17] ne "") { print output_filehandle "<h4>Team Rebounds: $stats_line[17]<\/h4>\n"; }
    
    # linescores in a table
    @road_linescore = parse_csv_line($linescores{rteam});
    @home_linescore = parse_csv_line($linescores{hteam});
    $column_count = $#road_linescore - 1; # assume both the same length
#    print "column count = $column_count\n";
    print output_filehandle "<table border\=1><tr><td><\/td>";
    for ($cc=1; $cc<$column_count-1; $cc++)
    {
	    if ($cc==5)
	    {
		    $period = "OT";
		}
	    elsif ($cc>5)
	    {
		    $period = "O".($cc-4);
		}
		else
		{
			$period = $cc;
		}
        print output_filehandle "<td align=\"right\" width=20>$period<\/td>";
    }
    print output_filehandle "<td><\/td><td align=\"right\" width=20>F<\/td><br>\n";

    print output_filehandle "<tr><td>$info{rteam}<\/td>";
    for ($cc=2; $cc<$column_count; $cc++)
    {
        print output_filehandle "<td align=\"right\">$road_linescore[$cc]<\/td>";
    }
    print output_filehandle "<td><\/td><td align=\"right\">$road_linescore[$column_count+1]<\/td><\/tr>\n";
    
    print output_filehandle "<tr><td>$info{hteam}<\/td>";
    for ($cc=2; $cc<$column_count; $cc++)
    {
        print output_filehandle "<td align=\"right\">$home_linescore[$cc]<\/td>";
    }
    print output_filehandle "<td><\/td><td align=\"right\">$home_linescore[$column_count+1]<\/td><\/tr>\n";

    print output_filehandle "<\/table>\n";
    
    @road_coach_line = parse_csv_line($coaches{rteam});
    @home_coach_line = parse_csv_line($coaches{hteam});

    print output_filehandle "<h4>Head Coaches: ";
    print output_filehandle "$info{rteam} - <a href=\"$br_coach_link\/$road_coach_line[2].html\">$road_coach_line[3] $road_coach_line[4]<\/a>";
    print output_filehandle ", ";
    print output_filehandle "$info{hteam} - <a href=\"$br_coach_link\/$home_coach_line[2].html\">$home_coach_line[3] $home_coach_line[4]<\/a>";
    print output_filehandle "<p>\n";
        
    # Omit the following fields if they are empty
    if ($info{note} ne "") { print output_filehandle "Game Notes: $info{note}<p>\n"; }
    if ($info{prelim} ne "") { print output_filehandle "Preliminary Game: $info{prelim}<p>\n"; }
    if ($info{event} ne "") { print output_filehandle "Special Event: $info{event}<p>\n"; }
    if ($info{attendance} ne "") { print output_filehandle "Attendance: $info{attendance}<br>\n"; }
    if ($info{ref1} ne "") { print output_filehandle "Referees: $info{ref1}, $info{ref2}<br>\n"; }
    if ($info{starttime} ne "") { print output_filehandle "Start Time: $info{starttime} $info{timezone}<br>\n"; }
    if ($info{radio} ne "") { print output_filehandle "Boston Radio: $info{radio}<br>\n"; }
    if ($info{tv} ne "") { print output_filehandle "Boston TV: $info{tv}\n"; }

    if ($sources_note ne "") { print output_filehandle "<p style = \"font-size:50%\;\">Sources: $sources_note</p>\n"; }
    
    print output_filehandle "<\/h4>\n";
    print output_filehandle "<hr>\n";

} # end of sub dump_data_to_file()

# ===============================================================


$start_of_boxscore = "gamebxt";

# default filenames
$input_filename = "input.csv";
$output_filename = "output.html";

getopts('i:o:h:t:',\%cli_opt);


if (exists ($cli_opt{"i"}))
{
    $input_filename = $cli_opt{"i"};
}

if (exists ($cli_opt{"o"}))
{
    $output_filename = $cli_opt{"o"};
}

if (exists ($cli_opt{"h"}))
{
	usage();
	exit;
}

if (exists ($cli_opt{"t"}))
{
	$page_title = $cli_opt{"t"};
}
else
{
	print "Enter page title: ";
	$page_title = getstring();
}

# open for reading
if (!open(input_filehandle, "$input_filename")) 
{
        die "Can't open input file $input_filename\n";
}

# open for writing, creating if needed
if (!open(output_filehandle, ">$output_filename")) 
{
        close(input_filehandle);
        die "Can't open output file $output_filename\n";
}

# start setting up the html file
print output_filehandle "<html>\n<head>\n";
print output_filehandle "<style type=\"text/css\">\n<!--\n";
print output_filehandle "h1 { font-family: Georgia, Verdana, Arial, sans-serif;\n   }\n";
print output_filehandle "h2 { font-family: Georgia, Verdana, Arial,  sans-serif;\n   }\n";
print output_filehandle "h3 { font-family: Georgia, Verdana, Arial,  sans-serif;\n   }\n";
print output_filehandle "h4 { font-family: Georgia, Verdana, Arial,  sans-serif;\n   }\n";
print output_filehandle "td { font-family: Georgia, Verdana, Arial,  sans-serif;\n   }\n";
print output_filehandle "-->\n<\/style>\n";
print output_filehandle "<meta name=\"description\" content=\"Historical NBA Box Scores\">\n";
print output_filehandle "<meta name=\"keywords\" content=\"Boston Celtics, Bill Russell, Red Auerbach, NBA, Box Scores, Boxscores, Box Score, Boxscore\">\n";
print output_filehandle "<title>$page_title - BOXTOP box scores<\/title>\n";
print output_filehandle "<\/head>\n";

print output_filehandle "<h1>$page_title<\/h1>\n";
print output_filehandle "<h3>For more seasons and details on this data, <a href=\"http://www.michaelhamel.net/boxtop-project\">click here<\/a><\/h3>\n";

my $first_gamebxt_read = "no";

# ####
# Step one - scan the input file to build index hashes, indexed by index_count
# ####
my %index_date, %index_hteam, %index_rteam, %index_hscore, %index_rscore, %index_title;

while ($line = <input_filehandle>)
{
    # read until we read a "gamebxt" which tells us we're done with the previous boxscore
    # but skip everything until after we read the first one
    if ($first_gamebxt_read eq "no")
    {
	    if ($line =~ /^$start_of_boxscore/)
	    {
		    # flip the flag, but ignore this line
		    $first_gamebxt_read = "yes";
		}
		# else just skip the line
	}			  
    elsif ($line =~ /^$start_of_boxscore/)
    {
        $index_count++;
    }
    elsif ($line =~ /^version/)
    {
        # ignore
    }
    elsif ($line =~ /^info/)
    {
        # split the line and add date and team names to hash (drop the rest on the floor)
        @this_line_array = parse_csv_line($line);
        
        # grab date
        if ($this_line_array[1] eq "date")
        {
            $index_date{$index_count} = $this_line_array[2];
        }
        elsif ($this_line_array[1] eq "rteam")
        {
            $index_rteam{$index_count} = $this_line_array[2];
        }
        elsif ($this_line_array[1] eq "hteam")
        {
            $index_hteam{$index_count} = $this_line_array[2];
        }
        elsif ($this_line_array[1] eq "title")
        {
            $index_title{$index_count} = $this_line_array[2];
        }
    }
    elsif ($line =~ /^coach/)
    {
	    # ignore
    }
    elsif ($line =~ /^stat/)
    {
	    # ignore
    }
    elsif ($line =~ /^tstat/)
    {
	    # ignore
    }
    elsif ($line =~ /^linescore/)
    {
        # split the line and add final score to hash
        @this_line_array = parse_csv_line($line);
        if ($this_line_array[1] eq "rteam")
        {
	        $index_rscore{$index_count} = $this_line_array[$#this_line_array];
    	}
        elsif ($this_line_array[1] eq "hteam")
        {
	        $index_hscore{$index_count} = $this_line_array[$#this_line_array];
    	}
    }   	
}

close(input_filehandle);

# Now dump the index into the output file
print output_filehandle "<table cellspacing\=5>\n";

# old 1 column format
#for ($index_scan=1; $index_scan <= $index_count; $index_scan++)
#{
#	print output_filehandle "<tr><td><a href=\"\#Game$index_scan\">$index_date{$index_scan}<\/a><\/td><td>$index_rteam{$index_scan} ($index_rscore{$index_scan}) vs. $index_hteam{$index_scan} ($index_hscore{$index_scan})<\/td><td>$index_title{$index_scan}<\/td><\/tr>\n";
#}

# 2 column format
$first_column_length = int($index_count / 2);

# print "column = $first_column_length\n";

for ($index_scan=1; $index_scan <= $first_column_length; $index_scan++)
{
	$index_scan_right_column = $index_scan + $first_column_length;
	print output_filehandle "<tr>";
	print output_filehandle "<td><a href=\"\#Game$index_scan\">$index_date{$index_scan}<\/a><\/td><td>$index_rteam{$index_scan} ($index_rscore{$index_scan}) vs. $index_hteam{$index_scan} ($index_hscore{$index_scan})<\/td><td>$index_title{$index_scan}<\/td>";
	print output_filehandle "<td><a href=\"\#Game$index_scan_right_column\">$index_date{$index_scan_right_column}<\/a><\/td><td>$index_rteam{$index_scan_right_column} ($index_rscore{$index_scan_right_column}) vs. $index_hteam{$index_scan_right_column} ($index_hscore{$index_scan_right_column})<\/td><td>$index_title{$index_scan_right_column}<\/td>";
	print output_filehandle "<\/tr>\n";
}

# Add 1 more in right column if we have an odd number of games
if ($index_count != ($first_column_length * 2))
{
	print output_filehandle "<tr>";
	print output_filehandle "<td><\/td><td><\/td><td><\/td>";
	print output_filehandle "<td><a href=\"\#Game$index_count\">$index_date{$index_count}<\/a><\/td><td>$index_rteam{$index_count} ($index_rscore{$index_count}) vs. $index_hteam{$index_count} ($index_hscore{$index_count})<\/td><td>$index_title{$index_count}<\/td>";
	print output_filehandle "<\/tr>\n";
}

print output_filehandle "<\/table><hr>\n";

# ####
# Step two - scan the input file again to build the actual boxscores
# ####

# re-open for reading
if (!open(input_filehandle, "$input_filename")) 
{
        die "Can't re-open input file $input_filename\n";
}

my $ref_count = 1;

$first_gamebxt_read = "no";

while ($line = <input_filehandle>)
{
    # read until we read a "gamebxt" which tells us to loop back around to the next boxscore
    if ($first_gamebxt_read eq "no")
    {
	    if ($line =~ /^$start_of_boxscore/)
	    {
		    # flip the flag, but ignore this line
		    $first_gamebxt_read = "yes";
		}
		# else just skip the line
	}
    elsif ($line =~ /^$start_of_boxscore/)
    {
        dump_data_to_file();
        $ref_count = 1;
        
        # clear all hashes
        %info = ();
        %coaches = ();
        %team_stats = ();
        %linescores = ();
        %road_player_stats = ();
        %home_player_stats = ();
        $sources_note = "";
    }
    elsif ($line =~ /^version/)
    {
        # ignore
    }
    elsif ($line =~ /^info/)
    {
        # split the line and add to hash, but save a copy of the original line because parse_csv_line() destroys it
        $save_this_line = $line;
        @this_line_array = parse_csv_line($line);
        
        # special case for refs
        if ($this_line_array[1] eq "ref")
        {
            $info{$this_line_array[1].$ref_count} = $this_line_array[2];
            $ref_count++;
        }
        # special case for game notes (concatenate)
        elsif (($this_line_array[1] eq "note") ||
        	   ($this_line_array[1] eq "event") ||
        	   ($this_line_array[1] eq "prelim"))
        {
	        # the following works, but we want to insert '...' only in between entries, not after last entry
	        # it also does not support commas inside the note
#	        $info{note} = $info{note} . $this_line_array[2];

			# grab everything except for "info,note," and remove any CR/LF
			# note, event, prelim are all different lengths so we need to use correct width
			$complete_note = substr($save_this_line,(6 + length($this_line_array[1])));
			chomp($complete_note);    
			
#			print ("This is $this_line_array[1] $complete_note\n");

	        if (exists($info{$this_line_array[1]}))
	        {
		        # Add to output
		        $info{$this_line_array[1]} = $info{$this_line_array[1]} . " ... " . $complete_note;
	    	}
	    	else
	    	{
		    	# First note for this game
	            $info{$this_line_array[1]} = $complete_note;
	    	}
    	}
        else
        {
            $info{$this_line_array[1]} = $this_line_array[2];
        }
    }
    elsif ($line =~ /^coach/)
    {
        # split the line and add to hash
        $copyline = $line;
        @this_line_array = parse_csv_line($line);
        $coaches{$this_line_array[1]} = $copyline;
    }
    elsif ($line =~ /^stat/)
    {
        # split the line and add to hash
        $copyline = $line;
        @this_line_array = parse_csv_line($line);
        if ($this_line_array[1] eq "rteam")
        {
            $road_player_stats{$this_line_array[3]} = $copyline;
        }
        else
        {
            $home_player_stats{$this_line_array[3]} = $copyline;
        }
    }
    elsif ($line =~ /^tstat/)
    {
        # split the line and add to hash
        $copyline = $line;
        @this_line_array = parse_csv_line($line);
        $team_stats{$this_line_array[1]} = $copyline;
    }
    elsif ($line =~ /^linescore/)
    {
        # split the line and add to hash
        $copyline = $line;
        @this_line_array = parse_csv_line($line);
        $linescores{$this_line_array[1]} = $copyline;
    }   
    elsif ($line =~ /^sources/)
    {
        @this_line_array = parse_csv_line($line);
        $sources_note = $this_line_array[1];
    }


} # end of main loop


dump_data_to_file();

add_footer();

print output_filehandle "\n<\/html>\n";

close (output_filenandle);

print "File $output_filename created.\n";
