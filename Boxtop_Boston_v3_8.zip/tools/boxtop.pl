# ===============================================================
# 
# boxtop.pl
#
# (c) 2010-2011 Michael Hamel
#
# This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License. To view a copy of this license, visit # http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.
#
# Version history
# 12/30/2010  1.0  MH  Initial version
# 06/25/2011  1.1  MH  Merging input format options into a single script
#
# ===============================================================


#! usr/bin/perl
use Getopt::Std;
use Time::Local;
use Date::Calc qw(:all);

# ===============================================================

sub usage
{
    print "Quickly input multiple boxscores and save using the boxtop format (.csv)\n";
    print "Supports shortcuts for team names and common Boston Celtics player names,\n";
    print "because the intention of this script was to support data entry of Celtics\n";
    print "boxscores between 1956 and 1969.\n";
    print "\n";
    print "Boxscores can be entered as 'basic' (With limited stats) or 'complete',\n";
    print "where 'complete' is based on stats that were official from 1952 through 1970.\n";
    print "\n";
    print "\nUSAGE:\n boxtop.pl [-o outputfilename]\n";
    print " Default filename is output.csv unless specified.\n";

}
# end of sub usage()

# ===============================================================

sub getstring
{
    $string = <>;
    chomp($string); # strip off CR
    return $string;
}
# end of sub getstring()

# ===============================================================

%team_list =
(   "bos" => "Boston Celtics",
    "phiw" => "Philadelphia Warriors",
    "p76" => "Philadelphia 76ers",
    "ny" => "New York Knickerbockers",
    "atl" => "Atlanta Hawks",
    "stl" => "St. Louis Hawks",
    "min" => "Minneapolis Lakers",
    "la" => "Los Angeles Lakers",
    "syr" => "Syracuse Nationals",
    "roch" => "Rochester Royals",
    "cin" => "Cincinnati Royals",
    "sf" => "San Francisco Warriors",
    "det" => "Detroit Pistons",
    "sd" => "San Diego Rockets",
    "sea" => "Seattle Supersonics",
    "milw" => "Milwaukee Bucks",
    "phoe" => "Phoenix Suns",
    "balt" => "Baltimore Bullets",
    "chip" => "Chicago Packers",
    "chiz" => "Chicago Zephyrs",
    "chi" => "Chicago Bulls",
);

sub getteamstring
{
    $string = <>;
    chomp($string); # strip off CR
    if (exists($team_list{$string})) 
    {
        $string = $team_list{$string};
    }
    return $string;
}
# end of sub getteamstring()

# ===============================================================

# To keep this simple, we support automatic lookup only for teams who played
# in a single arena for their existence (1956-57 through 1968-69).
#
# Some teams moved during a season, which would make automating teams
# that played in multiple arenas non-trivial, and some teams such as
# the Warriors (Phila & SF) and 76ers played in multiple arenas during a
# single season, which makes automation impossible.

%arena_list =
(   
    "Boston Celtics" => "Boston Garden",
    "New York Knickerbockers" => "Madison Square Garden", # Moved into MSG IV during 1968
    "Atlanta Hawks" => "Alexander Memorial Coliseum",
    "St. Louis Hawks" => "Kiel Auditorium",
    "Minneapolis Lakers" => "Minneapolis Auditorium",
    "Syracuse Nationals" => "Onondaga County War Memorial",
    "Rochester Royals" => "Rochester War Memorial",
    "Cincinnati Royals" => "Cincinnati Gardens",
    "San Diego Rockets" => "San Diego Sports Arena",
    "Seattle Supersonics" => "Seattle Center Coliseum",
    "Milwaukee Bucks" => "The Mecca",
    "Phoenix Suns" => "Arizona Veterans' Memorial Coliseum",
    "Baltimore Bullets" => "Baltimore Civic Center",
    "Chicago Packers" => "Chicago Amphitheater",
    "Chicago Zephyrs" => "Chicago Stadium",
# 1967-68 onward    "Chicago Bulls" => "Chicago Stadium",
);

sub getarenastring(@)
{
	$team_name = $_[0];	

    if (exists($arena_list{$team_name})) 
    {
        $string = $arena_list{$team_name};
    }
	else
	{
		# prompt for it
		print "Arena: ";
    	$string = <>;
    	chomp($string); # strip off CR
	}
        
    return $string;
}
# end of sub getarenastring()

# ===============================================================

%city_list =
(   
    "Boston Celtics" => "Boston",
    "New York Knickerbockers" => "New York",
    "Atlanta Hawks" => "Atlanta",
    "St. Louis Hawks" => "St. Louis",
    "Minneapolis Lakers" => "Minneapolis",
    "Syracuse Nationals" => "Syracuse",
    "Rochester Royals" => "Rochester",
    "Cincinnati Royals" => "Cincinnati",
    "San Diego Rockets" => "San Diego",
    "Seattle Supersonics" => "Seattle",
    "Milwaukee Bucks" => "Milwaukee",
    "Phoenix Suns" => "Phoenix",
    "Baltimore Bullets" => "Baltimore",
    "Chicago Packers" => "Chicago",
    "Chicago Zephyrs" => "Chicago",
    "Chicago Bulls" => "Chicago",
    "Philadelphia 76ers" => "Philadelphia",
    "Philadelphia Warriors" => "Philadelphia",
    "Detroit Pistons" => "Detroit",
);

sub getcitystring(@)
{
	$team_name = $_[0];	

    if (exists($city_list{$team_name})) 
    {
        $string = $city_list{$team_name};
    }
	else
	{
		# prompt for it
		print "City: ";
    	$string = <>;
    	chomp($string); # strip off CR
	}
        
    return $string;
}
# end of sub getcitystring()

# ===============================================================

%state_abbreviation_list =
(   
    "AL" => "Alabama",
    "AK" => "Alaska",
    "AZ" => "Arizona",
    "AR" => "Arkansas",
    "CA" => "California",
    "CO" => "Colorado",
    "CT" => "Connecticut",
    "DE" => "Delaware",
    "DC" => "Wash DC",
    "FL" => "Florida",
    "GA" => "Georgia",
    "HI" => "Hawaii",
    "ID" => "Idaho",
    "IL" => "Illinois",
    "IN" => "Indiana",
    "IA" => "Iowa",
    "KS" => "Kansas",
    "KY" => "Kentucky",
    "LA" => "Louisiana",
    "ME" => "Maine",
    "MD" => "Maryland",
    "MA" => "Massachusetts",
    "MI" => "Michigan",
    "MN" => "Minnesota",
    "MS" => "Mississippi",
    "MO" => "Missouri",
    "MT" => "Montana",
    "NE" => "Nebraska",
    "NV" => "Nevada",
    "NH" => "New Hampshire",
    "NJ" => "New Jersey",
    "NM" => "New Mexico",
    "NY" => "New York",
    "NC" => "North Carolina",
    "ND" => "North Dakota",
    "OH" => "Ohio",
    "OK" => "Oklahoma",
    "OR" => "Oregon",
    "PA" => "Pennsylvania",
    "RI" => "Rhode Island",
    "SC" => "South Carolina",
    "SD" => "South Dakota",
    "TN" => "Tennessee",
    "TX" => "Texas",
    "UT" => "Utah",
    "VT" => "Vermont",
    "VA" => "Virginia",
    "WA" => "Washington",
    "WV" => "West Virginia",
    "WI" => "Wisconsin",
    "WY" => "Wyoming",
);

# ===============================================================

%state_list =
(   
    "Boston Celtics" => "Massachusetts",
    "New York Knickerbockers" => "New York",
    "Atlanta Hawks" => "Georgia",
    "St. Louis Hawks" => "Missouri",
    "Minneapolis Lakers" => "Minnesota",
    "Syracuse Nationals" => "New York",
    "Rochester Royals" => "New York",
    "Cincinnati Royals" => "Ohio",
    "San Diego Rockets" => "California",
    "Seattle Supersonics" => "Washington",
    "Milwaukee Bucks" => "Wisconsin",
    "Phoenix Suns" => "Arizona",
    "Baltimore Bullets" => "Maryland",
    "Chicago Packers" => "Illinois",
    "Chicago Zephyrs" => "Illinois",
    "Chicago Bulls" => "Illinois",
    "Philadelphia 76ers" => "Pennsylvania",
    "Philadelphia Warriors" => "Pennsylvania",
    "Detroit Pistons" => "Michigan",
    "Los Angeles Lakers" => "California",
    "San Francisco Warriors" => "California"
);

sub getstatestring(@)
{
	$team_name = $_[0];	

    if (exists($state_list{$team_name})) 
    {
        $string = $state_list{$team_name};
    }
	else
	{
		# prompt for it, and support abbreviations
		print "State: ";
    	$string = <>;
    	chomp($string); # strip off CR
	    if (exists($state_abbreviation_list{$string})) 
	    {
	        $string = $state_abbreviation_list{$string};
	    }
	}
        
    return $string;
}
# end of sub getstatestring()

# ===============================================================

# From 1956-57 through 1968-69, there are only a handful of players whose
# BR id is NOT 01. In most cases, the conflict is caused by two names being
# similar but not identical. The cases where the names are identical are 
# listed below; in all of those cases there is NOT a conflict during the 
# 1956-57 through 1968-69 period.
%id_exception_hash =
(   
    "Bob Harrison" => "02", # Syracuse 1957-1958
    "Jack Turner" => "02", # Chicago Packers 1962; Different Jack Turner played in 1955
    "Bob Duffy" => "02", # Stl, NY, Det 1963-1965; Different Bob Duffy played in 1947
    "Wali Jones" => "02", # Baltimore 1965, Phi 1966-1969
    "Jim Barnett" => "02", # Boston 1967, San Diego 1968-1969
    "Matt Guokas" => "02", # Philadelphia 1967-1969; Different Matt Guokas played in 1947
    "Neil Johnson" => "02", # New York 1967-1968, Phoenix 1969
    "Freddie Lewis" => "02", # Different Freddie Lewis played 1949-1950
);

sub getid(@@)
{
    $first = $_[0];
    $last = $_[1];
    $coach = $_[2];

    # remove spaces from last name to handle cases like 'Van Arsdale' which gets translated to vanar<first>01
    $last =~ s/ //g;    
    
    if ($coach eq "coach")
    {	
	    # prompt for id (equal to player id if they ever played, 99 if they did not - always ends in 'c')
    	print "Two-digit id number: ";
	    $id = getstring();
	}
	else # this is a player, so just look it up	    
  	{
	  	$full_name = join(" ",$first,$last);
  		if (exists ($id_exception_hash{$full_name}))
  		{
		  	$id = $id_exception_hash{$full_name};
		}  
		else
		{
			$id = "01";
		}
	}
 
    if (length($last) > 5)
    {
        $last = substr($last,0,5);
    }

    if (length($first) > 2)
    {
	    if (substr($first,1,1) eq ".") # cover K.C. Jones case
	    {
		    $first = substr($first,0,1) . substr($first,2,1);
		}
		else
        {
	        $first = substr($first,0,2);
    	}
    }

    $myid = $last . $first . $id;

    # Note that for coaches who did not play in NBA, basketball reference uses 99 as default id, not 01
    if ($coach eq "coach")
    {
        $myid = $myid . "c";
    }

    # convert to all lower-case
    return lc($myid);

}
# end of sub getid()

# ===============================================================

sub get_day_of_week($)
{
	$date = $_[0];
	
   	my ($mon,$mday,$year) = split(/\//, $date);
 
	$wday = Day_of_Week($year,$mon,$mday);
	$the_day = Day_of_Week_to_Text($wday);
 
   	return($the_day);
}

# ===============================================================

sub display_boxscore_menu()
{
	print "Enter type of boxscore -\n";
	print " [a]        FGM/FTM/FTA/PTS\n";
	print " [b]asic    FGM/FTM/FTA/PF/PTS\n";
	print " [c]omplete MIN/FGM/FGA/FTM/FTA/REB/AST/PF/PTS\n";
	print " [s]imple   FGM/FTM/PTS\n";
	print " [d]one\n";
	print " : ";
}

# ===============================================================

# Support shortcuts for common Celtics names.
# Must have an entry in both hashes for each name, or the script will break.

%celtics_first_names =
(
    ".red" => "Red",
	".russ" => "Bill",
    ".hein" => "Tom",
    ".tsi" => "Lou",
    ".sam" => "Sam",
    ".kc" => "K.C.",
    ".hav" => "John",
    ".cooz" => "Bob",
    ".how" => "Bailey",
    ".sig" => "Larry",
    ".nel" => "Don",
    ".bry" => "Emmette",
    ".los" => "Jim",
    ".shar" => "Bill",
    ".satch" => "Tom",
    ".ram" => "Frank",
    ".lov" => "Clyde",
    ".wood" => "Woody",
    ".emb" => "Wayne",
    ".duck" => "Don",
);

%celtics_last_names =
(
    ".red" => "Auerbach",
	".russ" => "Russell",
    ".hein" => "Heinsohn",
    ".tsi" => "Tsioropoulos",
    ".sam" => "Jones",
    ".kc" => "Jones",
    ".hav" => "Havlicek",
    ".cooz" => "Cousy",
    ".how" => "Howell",
    ".sig" => "Siegfried",
    ".nel" => "Nelson",
    ".bry" => "Bryant",
    ".los" => "Loscutoff",
    ".shar" => "Sharman",
    ".satch" => "Sanders",
    ".ram" => "Ramsey",
    ".lov" => "Lovellette",
    ".wood" => "Sauldsberry",
    ".emb" => "Embry",
    ".duck" => "Chaney",
);


$output_filename = "output.csv";

getopts('o:h:',\%cli_opt);

if (exists ($cli_opt{"o"}))
{
    $output_filename = $cli_opt{"o"};
}

if (exists ($cli_opt{"h"}))
{
	usage();
	exit;
}

$done = "no";

# Open outpt file, appending or creating as necessary
if (!open(output_filehandle, ">>$output_filename")) 
{
        die "Can't open output file $output_filename\n";
}

%info;
%person;
%stats;

display_boxscore_menu();
$boxscore_type = getstring();

while ($done eq "no")
{

    # put the preamble first
    print output_filehandle "\ngamebxt\nversion,1\n";
    
    # get the common data first
    print "Date (MON/DAY/YEAR): ";
    $info{date} = getstring();

#    print "Day of week: ";
    $info{dayofweek} = get_day_of_week($info{date}); # getstring();
#    print "$info{dayofweek}\n";

    print "Game description (playoffs): ";
    $info{title} = getstring();

    print "Neutral site game? [y/n]";
    $neutral_site = getstring();

    if ($neutral_site eq "y")
    {
	    print "Team1 (Road): ";
	    $info{rteam} = getteamstring();
	
	    print "Team2 (Home): ";
	    $info{hteam} = getteamstring();
	    
	    print "Arena: ";
	    $info{arena} = getstring();
	    
	    print "City: ";
	    $info{city} = getstring();
	    
	    print "State: ";
	    $info{state} = getstring();
	}
	else
	{	     
	    print "Road Team: ";
	    $info{rteam} = getteamstring();
	
	    print "Home Team: ";
	    $info{hteam} = getteamstring();
	
	    # Attempt to derive arena, city, state information from the home team name
	  	$info{arena} = getarenastring($info{hteam});
	   	$info{city} = getcitystring($info{hteam});
	   	$info{state} = getstatestring($info{hteam});
	}

    # All Celtics games during this era were in the United States
    $info{country} = "USA";

    print "Attendance: ";
    $info{attendance} = getstring();

    print "Ref1: ";
    $info{ref1} = getstring();

    print "Ref2: ";
    $info{ref2} = getstring();

    # Only two refs during this era

    print "Start Time: ";
    $info{starttime} = getstring();

    $info{timezone} = "ET";

    print "Radio: ";
    $info{radio} = getstring();

    print "Television: ";
    $info{tv} = getstring();

#   print(%info);

    # Add general info to .csv
    print output_filehandle "info,date,$info{date}\n";
    print output_filehandle "info,dayofweek,$info{dayofweek}\n";
    print output_filehandle "info,rteam,$info{rteam}\n";
    print output_filehandle "info,hteam,$info{hteam}\n";
    print output_filehandle "info,title,$info{title}\n";
    print output_filehandle "info,arena,$info{arena}\n";
    print output_filehandle "info,city,$info{city}\n";
    print output_filehandle "info,state,$info{state}\n";
    print output_filehandle "info,country,$info{country}\n";
    print output_filehandle "info,attendance,$info{attendance}\n";
    print output_filehandle "info,ref,$info{ref1}\n";
    print output_filehandle "info,ref,$info{ref2}\n";
    print output_filehandle "info,starttime,$info{starttime}\n";
    print output_filehandle "info,timezone,$info{timezone}\n";
    print output_filehandle "info,radio,$info{radio}\n";
    print output_filehandle "info,tv,$info{tv}\n";

    # Visitors first
    $team_preamble = $info{rteam};
    $team_forfile = "rteam";
    for ($a=0; $a<2; $a++)
    {
        print "\n\nEnter info for $team_preamble\n\n";

        print "Coach ($team_preamble) first name: ";
        $first_name_temp = ucfirst(getstring());
        
        # Check for a shortcut name first - could include any player or coach in these hashes, not just Celtics
        if ($first_name_temp =~ /^\./)
        {
            if (exists($celtics_first_names{$first_name_temp}))
            {
                $person{first} = $celtics_first_names{$first_name_temp};
                $person{last} = $celtics_last_names{$first_name_temp};
            }
        }
        else
        {
	        # user entered first name, so prompt for last name
	        $person{first} = $first_name_temp;

	        print "Coach ($team_preamble) last name: ";
        	$person{last} = ucfirst(getstring());
		}

        $person{id} = getid($person{first},$person{last},"coach");
        $coach_technicals = "";

#       print(%person);
        print output_filehandle "coach,$team_forfile,$person{id},$person{first},$person{last},$coach_technicals\n";

        print "\nPlayer first name or s to stop: ";
        $first_name_temp = ucfirst(getstring());
                
        while ($first_name_temp ne "S") # note that we use ucfirst() on name string, so s or S becomes S
        {
            if ($first_name_temp =~ /^\./)
            {
                if (exists($celtics_first_names{$first_name_temp}))
                {
                    $person{first} = $celtics_first_names{$first_name_temp};
                    $person{last} = $celtics_last_names{$first_name_temp};
                }
                else
                {
                    print "NOT FOUND\n";
                    print "Player first name: ";
                    $person{first} = ucfirst(getstring());
                    print "Player last name: ";
                    $person{last} = ucfirst(getstring());
                }
            }
            else
            {
                $person{first} = $first_name_temp;
                print "Player last name: ";
                $person{last} = ucfirst(getstring());
            }
    
            $person{id} = getid($person{first},$person{last},"player");

            # fill in defaults
            $stats{MIN} = "";
            $stats{FGM} = "";
            $stats{FGA} = "";
            $stats{FTM} = "";
            $stats{FTA} = "";
            $stats{FG3M} = "";
            $stats{FG3A} = "";
            $stats{PF} = "";
            $stats{PTS} = "";
            $stats{OREB} = "";
            $stats{BLOCKS} = "";
            $stats{TURNOVERS} = "";
            $stats{STEALS} = "";
            $stats{TECHNICALFOUL} = "";
            $stats{REB} = "";
            $stats{AST} = "";
            
            if ($boxscore_type eq "a")
            {
                # basic input only, TSN/NYT style late 1960s
                print "FGM: ";
                $stats{FGM} = getstring();
                print "FTM: ";
                $stats{FTM} = getstring();
                print "FTA: ";
                $stats{FTA} = getstring();
                print "PTS: ";
                $stats{PTS} = getstring();
            }
            elsif ($boxscore_type eq "b")
            {
                # basic input only
                print "FGM: ";
                $stats{FGM} = getstring();
                print "FTM: ";
                $stats{FTM} = getstring();
                print "FTA: ";
                $stats{FTA} = getstring();
                print "PF: ";
                $stats{PF} = getstring();
                print "PTS: ";
                $stats{PTS} = getstring();
            }
            elsif ($boxscore_type eq "s")
            {
                # very basic input only
                print "FGM: ";
                $stats{FGM} = getstring();
                print "FTM: ";
                $stats{FTM} = getstring();
                print "PTS: ";
                $stats{PTS} = getstring();
            }
            else
            {
                # complete input
                print "MIN: ";
                $stats{MIN} = getstring();

                print "FGM: ";
                $stats{FGM} = getstring();
            	print "FGA: ";
                $stats{FGA} = getstring();
                print "FTM: ";
                $stats{FTM} = getstring();
                print "FTA: ";
                $stats{FTA} = getstring();

        	    print "REB: ";
            	$stats{REB} = getstring();
                print "AST: ";
                $stats{AST} = getstring();
	            print "PF: ";
    	        $stats{PF} = getstring();
                print "PTS: ";
                $stats{PTS} = getstring();
            }


            # stat,player,ID,FIRSTNAME,LASTNAME,MIN,FGM,FGA,FTM,FTA,3FGM,3FGA,PTS,OREB,REB,AST,PF,BLOCKS,TURNOVERS,STEALS
            print output_filehandle "stat,$team_forfile,player,$person{id},$person{first},$person{last},$stats{MIN},$stats{FGM},$stats{FGA},$stats{FTM},$stats{FTA},$stats{FG3M},$stats{FG3A},$stats{PTS},$stats{OREB},$stats{REB},$stats{AST},$stats{PF},$stats{BLOCKS},$stats{TURNOVERS},$stats{STEALS},$stats{TECHNICALFOUL}\n";

	        print "\nPlayer first name or s to stop: ";
    	    $first_name_temp = ucfirst(getstring());

        } # end of player entry loop

        # Team stats

        # Now get team stat line - yes, this is inefficient cut-and-pasting of code; minutes omitted.
        print "Enter TEAM stats for $team_preamble\n";

        # fill in defaults
        $stats{MIN} = "";
        $stats{FGM} = "";
        $stats{FGA} = "";
        $stats{FTM} = "";
        $stats{FTA} = "";
        $stats{FG3M} = "";
        $stats{FG3A} = "";
        $stats{PF} = "";
        $stats{PTS} = "";
        $stats{OREB} = "";
        $stats{BLOCKS} = "";
        $stats{TURNOVERS} = "";
        $stats{STEALS} = "";
        $stats{TECHNICALFOUL} = "";
        $stats{REB} = "";
        $stats{AST} = "";
        $stats{TEAMREB} = "";
            
        if ($boxscore_type eq "a")
        {
            # very basic input only
            print "FGM: ";
            $stats{FGM} = getstring();
            print "FTM: ";
            $stats{FTM} = getstring();
            print "FTA: ";
            $stats{FTA} = getstring();
            print "PTS: ";
            $stats{PTS} = getstring();
        }
        elsif ($boxscore_type eq "b")
        {
            # basic input only
            print "FGM: ";
            $stats{FGM} = getstring();
            print "FTM: ";
            $stats{FTM} = getstring();
            print "FTA: ";
            $stats{FTA} = getstring();
            print "PF: ";
            $stats{PF} = getstring();
            print "PTS: ";
            $stats{PTS} = getstring();
        }
        elsif ($boxscore_type eq "s")
        {
            # very basic input only
            print "FGM: ";
            $stats{FGM} = getstring();
            print "FTM: ";
            $stats{FTM} = getstring();
            print "PTS: ";
            $stats{PTS} = getstring();
        }
        else
        {
            # complete input
            print "MIN: ";
            $stats{MIN} = getstring();

            print "FGM: ";
            $stats{FGM} = getstring();
        	print "FGA: ";
            $stats{FGA} = getstring();
            print "FTM: ";
            $stats{FTM} = getstring();
            print "FTA: ";
            $stats{FTA} = getstring();

    	    print "REB: ";
        	$stats{REB} = getstring();
            print "AST: ";
            $stats{AST} = getstring();
            print "PF: ";
	        $stats{PF} = getstring();
            print "PTS: ";
            $stats{PTS} = getstring();
            
            print "TEAMREB: ";
            $stats{TEAMREB} = getstring();
        }

        # stat,rteam|hteam,CITY,NICKNAME,FGM,FGA,FTM,FTA,FG3M,FG3A,PTS,OREB,REB,AST,PF,BLOCKS,TURNOVERS,STEALS
        print output_filehandle "tstat,$team_forfile,$stats{MIN},$stats{FGM},$stats{FGA},$stats{FTM},$stats{FTA},$stats{FG3M},$stats{FG3A},$stats{PTS},$stats{OREB},$stats{REB},$stats{AST},$stats{PF},$stats{BLOCKS},$stats{TURNOVERS},$stats{STEALS},$stats{TEAMREB},$stats{TECHNICALFOUL}\n";

        # Linescore
        print "$team_preamble linescore (comma delimited): ";
        $linescore = getstring();
        print output_filehandle "linescore,$team_forfile,$linescore\n";
        
        # Setup for entry of home team stats    
        $team_preamble = $info{hteam};
        $team_forfile = "hteam";

    }

    print "\nSources for this boxscore: ";
    $sources_list = getstring();
    print output_filehandle "sources,$sources_list\n\n";

    # Save current file so we don't lose this boxscore if we crash
	close(output_filehandle);
	
	# Open output file, appending or creating as necessary
	if (!open(output_filehandle, ">>$output_filename")) 
	{
        die "Can't re-open output file $output_filename\n";
	}
        
    display_boxscore_menu();
    $boxscore_type = getstring();

    if ($boxscore_type eq "d")
    {
        $done = "yes";
    }

} # end of main while loop

close (output_filenandle);

print "File $output_filename created.\n";

