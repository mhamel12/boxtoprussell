# ===============================================================
# 
# refs.pl
#
# (c) 2011 Michael Hamel
#
# This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License. To view a copy of this license, visit # http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.
#
# Version history
# 03/21/2010  1.0  MH  Initial version
#
# ===============================================================


#! usr/bin/perl
use Getopt::Std;

my %referees;

my $game_count = 1;

# ===============================================================

sub usage
{
    print "Create table of referees based on a boxtop file.\n";
    print "Includes win-loss records from Boston's point-of-view.\n";
    print "\n";
    print "Output is written to a text file in .csv format\n";
    
    print "\n";
    print "\nUSAGE:\n refs.pl -n numberofregularseasongames [-i inputfilename] [-o outputfilename]\n";
    print " Must specify 'numberofregularseasongames' so the data set is split between\n";
    print " regular season and playoffs.\n";
    print " Default filenames are input.csv and refsoutput.txt unless specified.\n";
   
}
# end of sub usage()

# ===============================================================

# ===============================================================
# 
# parse_csv_line()
#
# Parses one line of a csv file and fills an array to return to caller.
#
# Input:
#
# Output:
#  Array that contains each element of the csv line.
#
# ===============================================================
sub parse_csv_line(@)
{
    ($line) = @_;

        # Note: If we don't declare this here, we end up re-using previously
    #       declared variable on our next trip through here!
        my @csv_elements;

        # trick - add a comma at the end of the line in place of the CR
        # makes searching easier...
        chomp($line);
        $line = join(",",$line,"");
    
        while ((my $next_comma = index($line,",")) >= 0)
        {
            # Grab next column header.
            push @csv_elements, substr($line,0,$next_comma);

            $line = substr($line,($next_comma+1),length($line));
        }
    
        return(@csv_elements);
}
# end of sub parse_csv_line()

# =====================================================================

sub dump_to_file($)
{
	$preamble = $_[0];	
	
	$total_refs = 0;
	
	print output_filehandle "$preamble referee listing based on boxscores from .csv file\n";
	
	print output_filehandle "Name,Wins,Losses\n";
	foreach $value (sort keys %referees)
	{
		print output_filehandle "$value,$referees{$value}[0],$referees{$value}[1]\n";
	
		$total_refs += ($referees{$value}[0] + $referees{$value}[1]);
	}
	
	print output_filehandle "TOTAL Games : $total_refs (should be 2x total games if complete)\n\n";

}
# end of sub dump_to_file()

# ===============================================================


$start_of_boxscore = "gamebxt";

# default filenames
$input_filename = "input.csv";
$output_filename = "refsoutput.txt";

getopts('i:o:n:h:',\%cli_opt);


if (exists ($cli_opt{"i"}))
{
    $input_filename = $cli_opt{"i"};
}

if (exists ($cli_opt{"o"}))
{
    $output_filename = $cli_opt{"o"};
}

if (exists ($cli_opt{"n"}))
{
	$number_of_regular_season_games = $cli_opt{"n"};
}
else # this is a required argument
{
	usage();
	exit;
}

if (exists ($cli_opt{"h"}))
{
	usage();
	exit;
}

# open for reading
if (!open(input_filehandle, "$input_filename")) 
{
        die "Can't open input file $input_filename\n";
}

# open for writing, creating if needed
if (!open(output_filehandle, ">$output_filename")) 
{
        close(input_filehandle);
        die "Can't open output file $output_filename\n";
}

print output_filehandle "Checking $input_filename...\n\n";

my $lines_read_from_input_file = 0;
my $first_gamebxt_read = "no";

# clear all hashes
%referees = ();

# main loop

my $ref1 = "";
my $ref2 = "";

while ($line = <input_filehandle>)
{
	$lines_read_from_input_file++;
	
    # read until we read a "gamebxt" which tells us to loop back around to the next boxscore
    # but skip everything until after we read the first one
    if ($first_gamebxt_read eq "no")
    {
	    if ($line =~ /^$start_of_boxscore/)
	    {
		    # flip the flag, but ignore this line
		    $first_gamebxt_read = "yes";
		}
		# else just skip the line
	}			  
    elsif ($line =~ /^$start_of_boxscore/)
    {
	    # Determine win/loss and push into hash
		if ($ref1 ne "")
		{
			if (exists($referees{$ref1}))
			{
				if ($team_pts > $opp_pts)
				{
					$referees{$ref1}[0]++;
				}
				else
				{
					$referees{$ref1}[1]++;
				}
			}
			else # create new entry in hash
			{
				if ($team_pts > $opp_pts)
				{
					$referees{$ref1}[0]=1;
					$referees{$ref1}[1]=0;
				}
				else
				{
					$referees{$ref1}[0]=0;
					$referees{$ref1}[1]=1;
				}
			}
		}
		if ($ref2 ne "")
		{
			if (exists($referees{$ref2}))
			{
				if ($team_pts > $opp_pts)
				{
					$referees{$ref2}[0]++;
				}
				else
				{
					$referees{$ref2}[1]++;
				}
			}
			else # create new entry in hash
			{
				if ($team_pts > $opp_pts)
				{
					$referees{$ref2}[0]=1;
					$referees{$ref2}[1]=0;
				}
				else
				{
					$referees{$ref2}[0]=0;
					$referees{$ref2}[1]=1;
				}
			}
		}
			    
	    # Clear variables
	    $ref1 = "";
	    $ref2 = "";
	    
	    # we init game_count to 1 but do not increment it until AFTER processing the first game
	    # so when we've processed 50 games we'll be here with $game_count = 50 (or we will have exited
	    # this loop entirely)
	    if ($game_count == $number_of_regular_season_games)
	    {
		    dump_to_file("Regular Season");
		    
		    # clear all hashes
		    %referees = ();
		}
		
		$game_count++;
	}	
    elsif ($line =~ /^version/)
    {
        # ignore
    }
    elsif ($line =~ /^info/)
    {
        # split the line
        @this_line_array = parse_csv_line($line);
        
        # IMPORTANT
        # We make the assumption that the rteam/hteam is declared in the boxtop file first.
        
		if ($this_line_array[1] eq "rteam")
        {
            $road_team_name = $this_line_array[2];
            if ($road_team_name eq "Boston Celtics")
            {
	            $team_string = "rteam";
        	}
        }
        elsif ($this_line_array[1] eq "hteam")
        {
	        $home_team_name = $this_line_array[2];
            if ($home_team_name eq "Boston Celtics")
            {
	            $team_string = "hteam";
        	}
        }
        elsif ($this_line_array[1] eq "ref")
        {
	        if ($ref1 eq "")
	        {
		        $ref1 = $this_line_array[2];
	    	}
	    	else
	        {
		        $ref2 = $this_line_array[2];
	    	}
    	}
    }
    elsif ($line =~ /^coach/)
    {
        # ignore
    }
    elsif ($line =~ /^stat/)
    {
	    # ignore
    }
    elsif ($line =~ /^tstat/)
    {
        # split the line and add to hash
        @this_line_array = parse_csv_line($line);
        if ($this_line_array[1] eq $team_string)
        {
	        $team_pts = $this_line_array[9];
        }
        else
        {
	        $opp_pts = $this_line_array[9];
    	}
    }
    elsif ($line =~ /^linescore/)
    {
        # ignore
    }   


} # end of main loop

# Process all of the data (if team did not make playoffs) or just the playoff data
if ($game_count <= $number_of_regular_season_games)
{
    dump_to_file("Regular Season");
    if ($game_count < $number_of_regular_season_games)
    {
	    print "Warning only $game_count games processed (Regular Season = $number_of_regular_season_games games)\n";
	}
}
else
{
	# Process the last playoff game first
	
	    # Determine win/loss and push into hash
		if ($ref1 ne "")
		{
			if (exists($referees{$ref1}))
			{
				if ($team_pts > $opp_pts)
				{
					$referees{$ref1}[0]++;
				}
				else
				{
					$referees{$ref1}[1]++;
				}
			}
			else # create new entry in hash
			{
				if ($team_pts > $opp_pts)
				{
					$referees{$ref1}[0]=1;
					$referees{$ref1}[1]=0;
				}
				else
				{
					$referees{$ref1}[0]=0;
					$referees{$ref1}[1]=1;
				}
			}
		}
		if ($ref2 ne "")
		{
			if (exists($referees{$ref2}))
			{
				if ($team_pts > $opp_pts)
				{
					$referees{$ref2}[0]++;
				}
				else
				{
					$referees{$ref2}[1]++;
				}
			}
			else # create new entry in hash
			{
				if ($team_pts > $opp_pts)
				{
					$referees{$ref2}[0]=1;
					$referees{$ref2}[1]=0;
				}
				else
				{
					$referees{$ref2}[0]=0;
					$referees{$ref2}[1]=1;
				}
			}
		}
		
		dump_to_file("Playoff");
}

close (output_filenandle);

print "File $output_filename created.\n";
