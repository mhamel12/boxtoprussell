# ===============================================================
# 
# gamelog.pl
#
# (c) 2010-2014 Michael Hamel
#
# This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License. To view a copy of this license, visit # http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.
#
# Version history
# 04/05/2011  1.0  MH  Initial version
# 08/07/2011  1.1  MH  Rework to support bgames database script
# 06/23/2014  1.2  MH  Add coaching record text to distinguish vs. players, new shading and text format for season totals
#
# ===============================================================


#! usr/bin/perl
use Getopt::Std;

# single game stats
my $fgm;
my $ftm;
my $fta;
my $pf;
my $pts;
my $min;
my $fga;
my $reb;
my $ast;

my $road_team_points;
my $road_team_name;
my $home_team_points;
my $home_team_name;
my $person_team;
my $game_date;
my $game_title;
my $game_number;

my $person_is_a;

# Use simple variables for totals
# But TBD consider dumping totals BY team (would require storing totals in a hash)
my $totals_games_played;
my $totals_fgm;
my $totals_ftm;
my $totals_fta;
my $totals_pf;
my $totals_pts;
my $totals_min;
my $totals_fga;
my $totals_reb;
my $totals_ast;

# These are counters to determine how complete the season is
# We increment these whenever the stat entry is NOT an empty string
my $totals_counter_fgm;
my $totals_counter_ftm;
my $totals_counter_fta;
my $totals_counter_pf;
my $totals_counter_pts;
my $totals_counter_min;
my $totals_counter_fga;
my $totals_counter_reb;
my $totals_counter_ast;


my $output_filename;

# ===============================================================

sub usage
{
    print "Create game log for a specific player or coach based on boxtop file(s).\n";
    print "\n";
    print "Output is written to either an html file or a text file in .csv format\n";
    
    print "\n";
    print "\nUSAGE:";
    print "\n gamelog.pl -p playerid or coachid [-o HTMLoutputfilename]";
    print "\n            ( [-i inputfilename] [-l link to HTML filename]";
    print "\n            OR [-f configuration file] )";
    print "\n            [-v opponent filter] [-c CSVoutputfilename]";
    print "\n            [-a append mode] [-t output title]";
    print "\n\n";
    print " If linking to an HTML filename, must be in same folder as the gamelog\n";
    print " Append mode appends raw html with no header or footer to the output file\n";
    print "\n";
    print " Enclose opponent filter in quotes for best results\n";
    print " Note that -o takes precedence over -c\n";
    print " Default filenames are input.csv and <id>_log.htm unless specified.\n";
   
}
# end of sub usage()

# ===============================================================
# 
# parse_csv_line()
#
# Parses one line of a csv file and fills an array to return to caller.
#
# Input:
#
# Output:
#  Array that contains each element of the csv line.
#
# ===============================================================
sub parse_csv_line(@)
{
    ($line) = @_;

        # Note: If we don't declare this here, we end up re-using previously
    #       declared variable on our next trip through here!
        my @csv_elements;

        # trick - add a comma at the end of the line in place of the CR
        # makes searching easier...
        chomp($line);
        $line = join(",",$line,"");
    
        while ((my $next_comma = index($line,",")) >= 0)
        {
            # Grab next column header.
            push @csv_elements, substr($line,0,$next_comma);

            $line = substr($line,($next_comma+1),length($line));
        }
    
        return(@csv_elements);
}
# end of sub parse_csv_line()

# ===============================================================

$br_player_link = "http:\/\/www.basketball-reference.com\/players";
$br_coach_link = "http:\/\/www.basketball-reference.com\/coaches";

sub add_html_document_header($)
{
	$page_title = $_[0];
	
	# start setting up the html file
	print output_filehandle "<html>\n<head>\n";
#	print output_filehandle "<style type=\"text/css\">\n<!--\nh1 { font-family: Verdana, sans-serif;\n   }\nh2 { font-family: Verdana, sans-serif;\n   }\n-->\n<\/style>\n";
	
	print output_filehandle "<style type=\"text/css\">\n<!--\n";
	print output_filehandle "h1 { font-family: Georgia, Verdana, Arial, sans-serif;\n   }\n";
	print output_filehandle "h2 { font-family: Georgia, Verdana, Arial,  sans-serif;\n   }\n";
	print output_filehandle "h3 { font-family: Georgia, Verdana, Arial,  sans-serif;\n   }\n";
	print output_filehandle "h4 { font-family: Verdana, Arial,  sans-serif;\n   }\n";
	print output_filehandle "td { font-family: Georgia, Verdana, Arial,  sans-serif;\n   }\n";
	print output_filehandle "-->\n<\/style>\n";
	
	print output_filehandle "<title>$page_title<\/title>\n";
	print output_filehandle "<\/head>\n";
	
}
# end of add_html_document_header

sub add_html_header($$$)
{
	$name = $_[0];
	$id = $_[1];	
	$lastname = $_[2];

	# Add a link point so we can provide direct links to a particular player if desired.
	# For now, we are not creating a formal index	
	print output_filehandle "<a name=$id><\/a>\n";
	print output_filehandle "<h1>";

    $personid = $cli_opt{"p"};
    if ($id =~ /c$/) # this is a coach
	{
		print output_filehandle "<a href=\"$br_coach_link\/$id.html\">$name<\/a><\/h1>\n";
		print output_filehandle "<h2>Coaching Record</h2>\n";
	}
	else
	{
	    $ch = substr($id,0,1);
	    $start_of_lastname = substr($lastname,0,1);
	    if ($ch ne $start_of_lastname)
	    {
    	    # need to look for exceptions
    	    if ($id eq "abdulma01")
    	    {
    		    print output_filehandle "<a href=\"$br_player_link\/$ch\/$id.html\">$name<\/a> (Mahdi Abdul-Rahman)<\/h1>\n";
    	    }
    	    elsif ($id eq "abdulza01")
    	    {
    		    print output_filehandle "<a href=\"$br_player_link\/$ch\/$id.html\">$name<\/a> (Zaid Abdul-Aziz)<\/h1>\n";
    	    }
    	    else # we're looking for more exceptions, so just print to stdout and use normal header
    	    {
        	    print "WARNING: $id not a match for $name ($lastname) - need to edit gamelog.pl\n";
    		    print output_filehandle "<a href=\"$br_player_link\/$ch\/$id.html\">$name<\/a><\/h1>\n";
    	    }
	    }
	    else
	    {
		    print output_filehandle "<a href=\"$br_player_link\/$ch\/$id.html\">$name<\/a><\/h1>\n";
	    }
	}		
	print output_filehandle "<\/h1>\n";
	if ($opponent_filter ne " ")
	{
		print output_filehandle "<h4>filtered for $opponent_filter<\/h4>\n";
	}
}
# end of add_html_header

# ===============================================================

sub add_csv_header($)
{
	$page_title = $_[0];	
	
	print output_filehandle "$page_title vs. $opponent_filter\n";

}
# end of add_csv_header

# ===============================================================

sub add_html_footer()
{
	($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);

	print output_filehandle "<p>This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License.<br>To view a copy of this license, visit <a href=\"http:\/\/creativecommons.org\/licenses\/by-nc-sa\/3.0\/\">http:\/\/creativecommons.org\/licenses\/by-nc-sa\/3.0\/<\/a>\n";
	printf output_filehandle "<p>Web page created at %02d:%02d:%02d on %02s\/%02d\/%4d using gamelog.pl based on boxtop format data, (c) 2010-2014 Michael Hamel.\n",$hour,$min,$sec,$mon+1,$mday,$year+1900;
}
# end of sub add_html_footer()

# ===============================================================

sub add_csv_footer()
{
	($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);

	print output_filehandle "This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License.\n";
	print output_filehandle "To view a copy of this license visit http:\/\/creativecommons.org\/licenses\/by-nc-sa\/3.0\/\n";
	printf output_filehandle ".CSV file created at %02d:%02d:%02d on %02s\/%02d\/%4d using gamelog.pl based on boxtop format data (c) 2010-2014 Michael Hamel.\n",$hour,$min,$sec,$mon+1,$mday,$year+1900;
}
# end of sub add_csv_footer()

# ===============================================================

sub get_season_string($)
{
    $game_date = $_[0];
    
	# determine which season this is by looking at the final game date
    @final_game_date = split(/\//,$game_date);
    if ($final_game_date[0] < 8) # January-July
    {
		$year = $final_game_date[2];
	}
	else
	{
		$year = $final_game_date[2] + 1;
	}
	
	# now that we have the year (e.g. 1969) we create a string to represent the season (e.g. 1968-69)
	$season = ($year - 1) . "-" . substr($year,2,2);
	
	return($season);    
}
# end of get_season_string()

# ===============================================================

# Black on gray for sections, with reduced font size
my $table_section_header = "<tr bgcolor=dddddd style = \"font-size:80%\;\"><td align = \"left\">Date<\/td><td align = \"left\">Team<\/td><td align = \"left\">Road<\/td><td align = \"left\">Home<\/td><td align = \"right\">MIN<\/td><td align = \"right\">FGM<\/td><td align = \"right\">FGA<\/td><td align = \"right\">FTM<\/td><td align = \"right\">FTA<\/td><td align = \"right\">REB<\/td><td align = \"right\">AST<\/td><td align = \"right\">PF<\/td><td align = \"right\">PTS<\/td><td align = \"left\">RECORD<\/td><td align = \"left\">NOTES<\/td><\/tr>\n";
my $table_coach_section_header = "<tr bgcolor=dddddd style = \"font-size:80%\;\"><td align = \"left\">Date<\/td><td align = \"left\">Team<\/td><td align = \"left\">Road<\/td><td align = \"left\">Home<\/td><td align = \"left\">RECORD<\/td><td align = \"left\">NOTES<\/td><\/tr>\n";

# White on black for season totals
my $totals_section_header = "<tr bgcolor=black style = \"color:white\;\"><td align = \"left\">Season<\/td><td align = \"left\"><\/td><td align = \"left\"><\/td><td align = \"right\">Games<\/td><td align = \"right\">MIN<\/td><td align = \"right\">FGM<\/td><td align = \"right\">FGA<\/td><td align = \"right\">FTM<\/td><td align = \"right\">FTA<\/td><td align = \"right\">REB<\/td><td align = \"right\">AST<\/td><td align = \"right\">PF<\/td><td align = \"right\">PTS<\/td><td align = \"left\">RECORD<\/td><td align = \"left\"><\/td><\/tr>\n";
my $totals_coach_section_header = "<tr bgcolor=black style = \"color:white\;\"><td align = \"left\">Season<\/td><td align = \"left\"><\/td><td align = \"left\"><\/td><td align = \"right\">Games<\/td><td align = \"left\">RECORD<\/td><td align = \"left\"><\/td><\/tr>\n";


my $csv_section_header = "Date,Team,Road,Home,MIN,FGM,FGA,FTM,FTA,REB,AST,PF,PTS,RECORD,NOTES\n";
my $csv_coach_section_header = "Date,Team,Road,Home,RECORD,NOTES\n";
my $mywins;
my $mylosses;

my $season_year;

sub dump_to_file()
{
	if ($person_team eq 'rteam')
	{
		$myteam = $road_team_name;
		if ($road_team_points > $home_team_points)
		{
			$mywins++;
		}
		else
		{
			$mylosses++;
		}
	}
	else
	{
		$myteam = $home_team_name;
		if ($home_team_points > $road_team_points)
		{
			$mywins++;
		}
		else
		{
			$mylosses++;
		}
	}

	if ($output_type eq "html")
	{
    	if ($totals_games_played == 1)
    	{
        	# print the season only once
            $season_string = get_season_string($game_date);
            
            print output_filehandle "<tr><td><b>$season_string</b></td></tr>\n";    		    		
        }
        
		if ((($totals_games_played-1) % 10) == 0)
		{
			# print header
			if ($person_is_a eq "player")
		    {
			    print output_filehandle $table_section_header;
			}
			else
		    {
			    print output_filehandle $table_coach_section_header;
			}
		}	
	}
	else # for .csv just print the header once
	{
		if (($totals_games_played-1) == 0)
		{
			# print header
			if ($person_is_a eq "player")
		    {
			    print output_filehandle $csv_section_header;
			}
			else
		    {
			    print output_filehandle $csv_coach_section_header;
			}
		}	
	}

	if ($person_is_a eq "player")
    {
	    if ($output_type eq "html")
	    {
		    print output_filehandle "<tr onmouseover=\"this.style.backgroundColor = '#CCCCCC';\" onmouseout=\"this.style.backgroundColor = '#f7f6eb';\">";
		    if (length($html_link_filename) > 0)
		    {
			    print output_filehandle "<td align = \"left\"><a href=\"$html_link_filename#Game$game_number\">$game_date<\/a><\/td>";
		   	}
		   	else
		   	{
			    print output_filehandle "<td align = \"left\">$game_date<\/td>";
			}
		    print output_filehandle "<td align = \"left\">$myteam<\/td><td align = \"left\">$road_team_name $road_team_points<\/td><td align = \"left\">$home_team_name $home_team_points<\/td><td align = \"right\">$min<\/td>";
		    print output_filehandle "<td align = \"right\">$fgm<\/td><td align = \"right\">$fga<\/td><td align = \"right\">$ftm<\/td><td align = \"right\">$fta<\/td><td align = \"right\">$reb<\/td><td align = \"right\">$ast<\/td><td align = \"right\">$pf<\/td><td align = \"right\">$pts<\/td><td align = \"left\">$mywins-$mylosses<\/td><td align = \"left\">$game_title<\/td><\/tr>\n";
		}		    
		else
	    {
		    print output_filehandle "$game_date,$myteam,$road_team_name $road_team_points,$home_team_name $home_team_points,$min,$fgm,$fga,$ftm,$fta,$reb,$ast,$pf,$pts,$mywins-$mylosses,$game_title\n";
		}		    
	}
	else
	{
		if ($output_type eq "html")
	    {
		    print output_filehandle "<tr onmouseover=\"this.style.backgroundColor = '#CCCCCC';\" onmouseout=\"this.style.backgroundColor = '#f7f6eb';\">";
		    if (length($html_link_filename) > 0)
		    {
			    print output_filehandle "<td align = \"left\"><a href=\"$html_link_filename#Game$game_number\">$game_date<\/a><\/td>";
		   	}
		   	else
		   	{
			    print output_filehandle "<td align = \"left\">$game_date<\/td>";
			}
		    print output_filehandle "<td align = \"left\">$myteam<\/td><td align = \"left\">$road_team_name $road_team_points<\/td><td align = \"left\">$home_team_name $home_team_points<\/td><td align = \"left\">$mywins-$mylosses<\/td><td align = \"left\">$game_title<\/td><\/tr>\n";
		}
		else
	    {
		    print output_filehandle "$game_date,$myteam,$road_team_name $road_team_points,$home_team_name $home_team_points,$mywins-$mylosses,$game_title\n";
		}
	}

}
# end of sub dump_to_file()

# ===============================================================

sub dump_totals_to_file($$)
{
	$season = $_[0];
	$type = $_[1];
	
	$games_str = "Games";
	if ($totals_games_played < 2) 
	{
		$games_str = "Game";
	}
	
	if ($output_type eq "html")
	{
		if ($person_is_a eq "player")
	    {
		    print output_filehandle $totals_section_header;
		    print output_filehandle "<tr onmouseover=\"this.style.backgroundColor = '#CCCCCC';\" onmouseout=\"this.style.backgroundColor = '#f7f6eb';\"><td align = \"left\"><b>$season<\/b><\/td><td align = \"left\">TOTALS<\/td><td align = \"left\" style = \"font-size:70%\;\">$type<\/td><td align = \"right\">$totals_games_played<\/td><td align = \"right\">$totals_min<\/td><td align = \"right\">$totals_fgm<\/td><td align = \"right\">$totals_fga<\/td><td align = \"right\">$totals_ftm<\/td><td align = \"right\">$totals_fta<\/td><td align = \"right\">$totals_reb<\/td><td align = \"right\">$totals_ast<\/td><td align = \"right\">$totals_pf<\/td><td align = \"right\">$totals_pts<\/td><td align = \"left\">$mywins-$mylosses<\/td><\/tr>\n";
	    	print output_filehandle "<tr onmouseover=\"this.style.backgroundColor = '#CCCCCC';\" onmouseout=\"this.style.backgroundColor = '#f7f6eb';\"><td align = \"left\"><\/td><td align = \"left\" style = \"font-size:70%\;\">Games available<\/td><td align = \"right\"><\/td><td align = \"right\"><\/td><td align = \"right\">$totals_counter_min<\/td><td align = \"right\">$totals_counter_fgm<\/td><td align = \"right\">$totals_counter_fga<\/td><td align = \"right\">$totals_counter_ftm<\/td><td align = \"right\">$totals_counter_fta<\/td><td align = \"right\">$totals_counter_reb<\/td><td align = \"right\">$totals_counter_ast<\/td><td align = \"right\">$totals_counter_pf<\/td><td align = \"right\">$totals_counter_pts<\/td><\/tr>\n";
		}
		else
	    {
		    print output_filehandle $totals_coach_section_header;
		    print output_filehandle "<tr onmouseover=\"this.style.backgroundColor = '#CCCCCC';\" onmouseout=\"this.style.backgroundColor = '#f7f6eb';\"><td align = \"left\"><b>$season<\/b><\/td><td align = \"left\">TOTALS<\/td><td align = \"left\"  style = \"font-size:70%\;\">$type<\/td><td align = \"right\">$totals_games_played<\/td><td align = \"left\">$mywins-$mylosses<td align = \"right\"><\/td><\/tr>\n";
		}
	}
	else
	{
		if ($person_is_a eq "player")
	    {
		    print output_filehandle "$season,,,$totals_games_played $games_str,$totals_min,$totals_fgm,$totals_fga,$totals_ftm,$totals_fta,$totals_reb,$totals_ast,$totals_pf,$totals_pts,$mywins-$mylosses\n";
	    	print output_filehandle "Counters,,,,$totals_counter_min,$totals_counter_fgm,$totals_counter_fga,$totals_counter_ftm,$totals_counter_fta,$totals_counter_reb,$totals_counter_ast,$totals_counter_pf,$totals_counter_pts\n";
		}
		else
	    {
		    print output_filehandle "season,,,$totals_games_played $games_str,$mywins-$mylosses\n";
		}
	}
    
}
# end of sub dump_totals_to_file()

sub increment_totals()
{
	$totals_games_played++;
	
	if ($person_is_a eq "player")
	{
		$totals_min += $min;
		$totals_fgm += $fgm;
		$totals_fga += $fga;
		$totals_ftm += $ftm;
		$totals_fta += $fta;
		$totals_pts += $pts;
		$totals_reb += $reb;
		$totals_ast += $ast;
		$totals_pf += $pf;
					
		if ($min ne "")
		{
			$totals_counter_min++;
		}
		if ($fgm ne "")
		{
			$totals_counter_fgm++;
		}
		if ($fga ne "")
		{
			$totals_counter_fga++;
		}
		if ($ftm ne "")
		{
			$totals_counter_ftm++;
		}
		if ($fta ne "")
		{
			$totals_counter_fta++;
		}
		if ($pts ne "")
		{
			$totals_counter_pts++;
		}
		if ($reb ne "")
		{
			$totals_counter_reb++;
		}
		if ($ast ne "")
		{
			$totals_counter_ast++;
		}
		if ($pf ne "")
		{
			$totals_counter_pf++;
		}
	}
} # end of sub increment_totals()

# ===============================================================

##########################################################################
#
# Parse command line arguments
#
##########################################################################


$start_of_boxscore = "gamebxt";

# default filenames
@input_filename_array;
@html_link_filename_array;
@regular_season_game_array;

getopts('p:i:o:h:c:v:l:f:a:t:',\%cli_opt);

if (exists ($cli_opt{"p"}))
{
    $personid = $cli_opt{"p"};
    if ($personid =~ /c$/)
    {
	    $person_is_a = "coach";
	}
	else
	{
		$person_is_a = "player";
	}
}
else # this is a required argument
{
	usage();
	exit;
}

if (exists ($cli_opt{"a"}))
{
	print "Append mode not yet supported\n";
	$append_mode = "yes";
}
else
{
	$append_mode = "no";
}

if (exists ($cli_opt{"o"}))
{
    $output_filename = $cli_opt{"o"};
    $output_type = "html";
}
elsif (exists ($cli_opt{"c"}))
{
    $output_filename = $cli_opt{"c"};
    $output_type = "csv";
}
else # use default name and format for output file
{
	$output_filename = $personid."_log.htm";
	$output_type = "html";
}

if (exists ($cli_opt{"t"}))
{
	$page_title = $cli_opt{"t"};
}
else
{
	$page_title = $output_filename;
}

if (exists ($cli_opt{"v"}))
{
    $opponent_filter = $cli_opt{"v"};
}
else
{
	$opponent_filter = " ";
}

if (exists ($cli_opt{"f"}))
{
	$config_file = $cli_opt{"f"};
	
	if (!open(config_filehandle, "$config_file"))
	{
		die "Can't open config file $config_file\n";
	}
	
	while ($line = <config_filehandle>)
	{
		@this_line_array = parse_csv_line($line);
		push(@input_filename_array,$this_line_array[0]);
		push(@html_link_filename_array,$this_line_array[1]);
		push(@regular_season_games_array,$this_line_array[2]);
	}

	close(config_filehandle);
}
else # look for -i and -l options
{
	# set defaults
	$input_filename_array[0] = "input.csv";
	$html_link_filename_array[0] = "";

	if (exists ($cli_opt{"i"}))
	{
    	$input_filename_array[0] = $cli_opt{"i"};
	}

	if (exists ($cli_opt{"l"}))
	{
		$html_link_filename_array[0] = $cli_opt{"l"};
	}
}

if (exists ($cli_opt{"h"}))
{
	usage();
	exit;
}

##########################################################################
#
# Finished with argument parsing, let's get to work
#
##########################################################################

# open for writing, creating or appending depending on flag
if ($append_mode eq "yes")
{
	if (!open(output_filehandle, ">>$output_filename")) 
	{
        close(input_filehandle);
        die "Can't open output file $output_filename\n";
	}
}	
else
{
	if (!open(output_filehandle, ">$output_filename")) 
	{
        close(input_filehandle);
        die "Can't open output file $output_filename\n";
	}
}

if ($append_mode eq "no")
{
	# Output the document header
	if ($output_type eq "html")
	{
		add_html_document_header($page_title);
	}
}

# We haven't put a player/coach header in the file yet, so set this so we do it later
$player_header_missing = "yes";

my $seasons_read_in = 0; # used to index into regular_season_games_array[]
my $regular_season_games_this_season;

# Main loop starts here
foreach $element (@input_filename_array)
{
	$input_filename = $element;
	$html_link_filename = shift @html_link_filename_array;
	
	# open for reading
	if (!open(input_filehandle, "$input_filename")) 
	{
	        die "Can't open input file $input_filename\n";
	}
	
	my $lines_read_from_input_file = 0;
	my $first_gamebxt_read = "no";
	my $current_game_number = 0;
	
	$regular_season_games_this_season = $regular_season_games_array[$seasons_read_in];
	$found_playoff_game = "false";
	
	$totals_games_played = 0;
	$totals_fgm = 0;
	$totals_ftm = 0;
	$totals_fta = 0;
	$totals_pf = 0;
	$totals_pts = 0;
	$totals_min = 0;
	$totals_fga = 0;
	$totals_reb = 0;
	$totals_ast = 0;
	$totals_team_reb = 0;
	
	$totals_counter_fgm = 0;
	$totals_counter_ftm = 0;
	$totals_counter_fta = 0;
	$totals_counter_pf = 0;
	$totals_counter_pts = 0;
	$totals_counter_min = 0;
	$totals_counter_fga = 0;
	$totals_counter_reb = 0;
	$totals_counter_ast = 0;
	$totals_counter_team_reb = 0;
	
	$mywins = 0;
	$mylosses = 0;

	my $firstname;
	my $lastname;
	
	my $person_found = "false";
	
	# start of loop for a single input file
	
	while ($line = <input_filehandle>)
	{
		$lines_read_from_input_file++;
		
	    # read until we read a "gamebxt" which tells us to loop back around to the next boxscore
	    # but skip everything until after we read the first one
	    if ($first_gamebxt_read eq "no")
	    {
		    if ($line =~ /^$start_of_boxscore/)
		    {
			    # flip the flag, but ignore this line
			    $first_gamebxt_read = "yes";
			    $current_game_number++;
			}
			# else just skip the line
		}			  
	    elsif ($line =~ /^$start_of_boxscore/)
	    {
		    $current_game_number++;
		    
		    if ($person_found eq "true")
		    {
			    # only dump data if we've actually found the person in this game
			    if (($person_team eq "rteam" && $home_team_name=~/$opponent_filter/) ||
			        ($person_team eq "hteam" && $road_team_name=~/$opponent_filter/))
			    {
				    increment_totals();

					if ($player_header_missing eq "yes")
					{
						# now add the player header
						if ($output_type eq "html")
						{
							if ($person_is_a eq "player")
							{
								$name = "$firstname $lastname";
							}
							else
							{
								$name = "$firstname $lastname";
							}
							
							add_html_header($name,$personid,$lastname);
							print output_filehandle "<table>\n";
						}
						else
						{
							add_csv_header($title);
						}			
						
						$player_header_missing = "no";
					}	    
								    				
				    dump_to_file();
				}
			    
			    $person_found = "false";
			    if ($current_game_number > $regular_season_games_this_season)
			    {
    			    $found_playoff_game = "true";
			    }
			}
		    
#			print output_filehandle "Games $current_game_number [Regular=$regular_season_games_this_season]\n";
			
			if (($current_game_number == ($regular_season_games_this_season + 1)) &&
			    ($totals_games_played > 0))
			{
    			dump_totals_to_file($season_string,"Regular Season");
            
    			# reset all totals
               	$totals_games_played = 0;
            	$totals_fgm = 0;
            	$totals_ftm = 0;
            	$totals_fta = 0;
            	$totals_pf = 0;
            	$totals_pts = 0;
            	$totals_min = 0;
            	$totals_fga = 0;
            	$totals_reb = 0;
            	$totals_ast = 0;
            	$totals_team_reb = 0;
            	
            	$totals_counter_fgm = 0;
            	$totals_counter_ftm = 0;
            	$totals_counter_fta = 0;
            	$totals_counter_pf = 0;
            	$totals_counter_pts = 0;
            	$totals_counter_min = 0;
            	$totals_counter_fga = 0;
            	$totals_counter_reb = 0;
            	$totals_counter_ast = 0;
            	$totals_counter_team_reb = 0;

            	$mywins = 0;
            	$mylosses = 0;

  	   	    }
		}	
	    elsif ($line =~ /^version/)
	    {
	        # ignore
	    }
	    elsif ($line =~ /^info/)
	    {
	        # split the line
	        @this_line_array = parse_csv_line($line);
	        
			if ($this_line_array[1] eq "rteam")
	        {
	            $road_team_name = $this_line_array[2];
	        }
	        elsif ($this_line_array[1] eq "hteam")
	        {
		        $home_team_name = $this_line_array[2];
	        }
	        elsif ($this_line_array[1] eq "date")
	        {
		        $game_date = $this_line_array[2];
		        $game_number = $current_game_number; # This is relative to this particular input file
	    	}
	    	elsif ($this_line_array[1] eq "title")
	    	{
		    	$game_title = $this_line_array[2];
	    	}
	    }
	    elsif (($line =~ /^coach/) && ($person_is_a eq "coach"))
	    {
	        # split the line and add to hash
	        @this_line_array = parse_csv_line($line);
	        if ($this_line_array[2] eq $personid)
	        {
	        	# if $personid ends in a "c" we need to match against id in THIS ENTRY
	# coach,rteam|hteam,ID,FIRSTNAME,LASTNAME,TECHNICALFOUL
	# 0     1           2  3         4        5
				$person_found = "true";
				$person_team = $this_line_array[1];
				$firstname = $this_line_array[3];
				$lastname = $this_line_array[4];
			}
	    }
	    elsif (($line =~ /^stat/) && ($person_is_a eq "player"))
	    {
	        # split the line and add to hash
	        @this_line_array = parse_csv_line($line);
	        if ($this_line_array[3] eq $personid)
	        {
		        # This is the player we care about. Grab the stats.
				# stat,rteam,player,ramsefr01,Frank,Ramsey,,3,,5,6,,,11,,,,5,,,,
	# stat,rteam|hteam,player,ID,FIRSTNAME,LASTNAME,MIN,FGM,FGA,FTM,FTA,3FGM,3FGA,PTS,OREB,REB,AST,PF,BLOCKS,TURNOVERS,STEALS,TECHNICALFOUL
	# 0    1           2      3  4         5        6   7   8   9   10  11   12   13  14   15  16  17 18     19        20     21		
	
				$person_found = "true";
				$person_team = $this_line_array[1];
				$firstname = $this_line_array[4];
				$lastname = $this_line_array[5];
	
				$min = $this_line_array[6];
				$fgm = $this_line_array[7];
				$fga = $this_line_array[8];
				$ftm = $this_line_array[9];
				$fta = $this_line_array[10];
				$pts = $this_line_array[13];
				$reb = $this_line_array[15];
				$ast = $this_line_array[16];
				$pf = $this_line_array[17];
	        }
	    }
	    elsif ($line =~ /^tstat/)
	    {
	        # split the line and add to hash
	        @this_line_array = parse_csv_line($line);
	     
	        if ($this_line_array[1] eq "rteam")
	        {
	# tstat,rteam|hteam,MIN,FGM,FGA,FTM,FTA,FG3M,FG3A,PTS,OREB,REB,AST,PF,BLOCKS,TURNOVERS,STEALS,TEAMREBOUNDS,TECHNICALFOUL
	# 0     1           2   3   4   5   6   7    8    9   10   11  12  13 14     15        16     17           18
		        $road_team_points = $this_line_array[9];
	        }
	        elsif ($this_line_array[1] eq "hteam")
	        {
		        $home_team_points = $this_line_array[9];
	    	}
	        
	    }
	    elsif ($line =~ /^linescore/)
	    {
	        # ignore
	    }   
	
	
	} # end of loop for each input file
	
	close(input_filehandle);

	# Need to dump the last game here, if needed
	if ($person_found eq "true")
	{
	    if (($person_team eq "rteam" && $home_team_name=~/$opponent_filter/) ||
	        ($person_team eq "hteam" && $road_team_name=~/$opponent_filter/))
	    {		    
		    increment_totals();
		    
			dump_to_file();
		}
	}			
	
	# Then dump the totals; special case with no date or team info
	# TBD Consider dumping totals BY team (would require storing totals in a hash)
	if ($totals_games_played > 0)
	{
    	if ($found_playoff_game eq "true")
    	{
    		dump_totals_to_file($season_string,"Playoffs");
        }
        else
    	{
    		dump_totals_to_file($season_string,"Regular Season");
        }
	}

	$seasons_read_in++;
    $found_playoff_game = "false";
		
} # end of Main loop

# Complete the table
if ($output_type eq "html")
{
	print output_filehandle "</table>\n";
}

if ($append_mode eq "no")
{
	if ($output_type eq "html")
	{
		add_html_footer();
	}
	else
	{
		add_csv_footer();
	}
}

close (output_filenandle);

print "File $output_filename created.\n";
