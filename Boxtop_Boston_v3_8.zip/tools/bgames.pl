# ===============================================================
# 
# bgames.pl
#
# (c) 2011 Michael Hamel
#
# This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License. To view a copy of this license, visit # http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.
#
# Version history
# 08/07/2011  1.0  MH  Initial version
#
# ===============================================================


#! usr/bin/perl
use Getopt::Std;

my $output_filename;

# ===============================================================

sub usage
{
    print "\nCreate game logs for ALL players and coaches based on boxtop file(s).";
    print "\nOutput is written to an html file.\n";
    
    print "\n";
    print "\nUSAGE:";
    print "\n bgames.pl -f configuration file [-o outputfilename] [-t output file title]";
    print "\n           [-r lastnamerange]";
    print "\n\n";
    print "\n IMPORTANT: You must have a copy of gamelog.pl in the same directory";
    print "\n            where you are running this script.";
    print "\n";
    print "\n Default output filename is log.htm unless specified.";
    print "\n Default title is the outputfilename unless specified.";
    print "\n Range = 'ad' would create output with last names A-D";
    print "\n";
   
}
# end of sub usage()

# ===============================================================
# 
# parse_csv_line()
#
# Parses one line of a csv file and fills an array to return to caller.
#
# Input:
#
# Output:
#  Array that contains each element of the csv line.
#
# ===============================================================
sub parse_csv_line(@)
{
    ($line) = @_;

        # Note: If we don't declare this here, we end up re-using previously
    #       declared variable on our next trip through here!
        my @csv_elements;

        # trick - add a comma at the end of the line in place of the CR
        # makes searching easier...
        chomp($line);
        $line = join(",",$line,"");
    
        while ((my $next_comma = index($line,",")) >= 0)
        {
            # Grab next column header.
            push @csv_elements, substr($line,0,$next_comma);

            $line = substr($line,($next_comma+1),length($line));
        }
    
        return(@csv_elements);
}
# end of sub parse_csv_line()

# ===============================================================

$br_player_link = "http:\/\/www.basketball-reference.com\/players";
$br_coach_link = "http:\/\/www.basketball-reference.com\/coaches";

sub add_html_document_header($)
{
	$page_title = $_[0];
	
	# start setting up the html file
	print output_filehandle "<html>\n<head>\n";
#	print output_filehandle "<style type=\"text/css\">\n<!--\nh1 { font-family: Verdana, sans-serif;\n   }\nh2 { font-family: Verdana, sans-serif;\n   }\n-->\n<\/style>\n";

	print output_filehandle "<style type=\"text/css\">\n<!--\n";
	print output_filehandle "h1 { font-family: Georgia, Verdana, Arial, sans-serif;\n   }\n";
	print output_filehandle "h2 { font-family: Georgia, Verdana, Arial,  sans-serif;\n   }\n";
	print output_filehandle "h3 { font-family: Georgia, Verdana, Arial,  sans-serif;\n   }\n";
	print output_filehandle "h4 { font-family: Verdana, Arial,  sans-serif;\n   }\n";
	print output_filehandle "td { font-family: Georgia, Verdana, Arial,  sans-serif;\n   }\n";
	print output_filehandle "-->\n<\/style>\n";

	print output_filehandle "<title>$page_title<\/title>\n";
	print output_filehandle "<\/head>\n";
	print output_filehandle "<h1>$page_title<\/h1>\n";
	
}
# end of add_html_document_header

# ===============================================================

sub add_html_footer()
{
	($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);

	print output_filehandle "<hr><p>This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License.<br>To view a copy of this license, visit <a href=\"http:\/\/creativecommons.org\/licenses\/by-nc-sa\/3.0\/\">http:\/\/creativecommons.org\/licenses\/by-nc-sa\/3.0\/<\/a>\n";
	printf output_filehandle "<p>Web page created at %02d:%02d:%02d on %02s\/%02d\/%4d using bgames.pl and gamelog.pl based on boxtop format data, (c) 2010-2011 Michael Hamel.\n",$hour,$min,$sec,$mon+1,$mday,$year+1900;
}
# end of sub add_html_footer()

# ===============================================================


##########################################################################
#
# Parse command line arguments
#
##########################################################################


$start_of_boxscore = "gamebxt";

# default filenames
@input_filename_array;
@html_link_filename_array;

getopts('f:o:h:t:r:',\%cli_opt);

if (exists ($cli_opt{"h"}))
{
	usage();
	exit;
}

if (exists ($cli_opt{"o"}))
{
    $output_filename = $cli_opt{"o"};
}
else # use default name for output file
{
	$output_filename = "log.htm";
}

if (exists ($cli_opt{"t"}))
{
    $output_title = $cli_opt{"t"};
}
else # use default title for output file
{
	$output_title = $output_filename;
}

if (exists ($cli_opt{"f"}))
{
	$config_file = $cli_opt{"f"};
	
	if (!open(config_filehandle, "$config_file"))
	{
		die "Can't open config file $config_file\n";
	}
	
	while ($line = <config_filehandle>)
	{
		@this_line_array = parse_csv_line($line);
		push(@input_filename_array,$this_line_array[0]);
		push(@html_link_filename_array,$this_line_array[1]);
	}

	close(config_filehandle);
}
else
{
	die "Config file is a required argument\n";
}

if (exists ($cli_opt{"r"}))
{
	$range = lc($cli_opt{"r"});
}
else
{
	$range = "az";
}
$last_names_greater_or_equal_to = substr($range,0,1);
$last_names_less_or_equal_to = substr($range,1,1);

##########################################################################
#
# Finished with argument parsing, let's get to work
#
# Step One: Build list of player and coach ids
#
##########################################################################

my $temp_filename = "BoxtopIds.tmp";

# open for writing, creating if needed
if (!open(temp_filehandle, ">$temp_filename")) 
{
        die "Can't open temp file $temp_filename\n";
}

my %id_hash = ();

foreach $element (@input_filename_array)
{
	# open for reading
	if (!open(input_filehandle, "$element")) 
	{
	        die "Can't open input file $element\n";
	}
	
	while ($line = <input_filehandle>)
	{
	    if ($line =~ /^coach/)
	    {
	        # split the line and add to hash
	        @this_line_array = parse_csv_line($line);
	        $id = $this_line_array[2];
			$firstname = $this_line_array[3];
			$lastname = $this_line_array[4];
			
			$first_letter = lc(substr($id,0,1));
			if (($last_names_greater_or_equal_to le $first_letter) && ($first_letter le $last_names_less_or_equal_to))
			{
				if (exists($id_hash{$id}))
		        {
			        # This is just a sanity check to look for misspellings
			        if ($id_hash{$id} ne join(" ",$firstname,$lastname))
			        {
				        print "Coach Mismatch $id hash=$id_hash($id) but this entry = $firstname $lastname\n";
			    	}
		    	}
		    	else # add to hash
		    	{
			    	$id_hash{$id} = join(" ",$firstname,$lastname);
		    	}
	    	}
		}
	    elsif ($line =~ /^stat/)
	    {
	        # split the line and add to hash
	        @this_line_array = parse_csv_line($line);
	        $id = $this_line_array[3];
			$firstname = $this_line_array[4];
			$lastname = $this_line_array[5];
		
			$first_letter = lc(substr($id,0,1));
			if (($last_names_greater_or_equal_to le $first_letter) && ($first_letter le $last_names_less_or_equal_to))
			{
				if (exists($id_hash{$id}))
		        {
			        # This is just a sanity check to look for misspellings
			        if ($id_hash{$id} ne join(" ",$firstname,$lastname))
			        {
				        print "Mismatch $id hash=$id_hash{$id} but this entry = $firstname $lastname\n";
			    	}
		    	}
		    	else # add to hash
		    	{
			    	$id_hash{$id} = join(" ",$firstname,$lastname);
		    	}
	    	}
	    }
	}
}


# Sort the hash and dump to temp file
foreach $key (sort keys %id_hash)
{
	print temp_filehandle "$key\n";
}


close (temp_filehandle);

###############################################################
#
# Step Two: Now re-open the tmp file and pass the ids to gamelog.pl
#
###############################################################

# open temp file for reading
if (!open(temp_filehandle, "$temp_filename")) 
{
        die "Can't open temp file $temp_filename\n";
}

# open the output file for writing, creating if needed
if (!open(output_filehandle, ">$output_filename")) 
{
        die "Can't open output file $output_filename\n";
}

add_html_document_header($output_title);

close(output_filehandle);

$first_char = "";
$new_first_char = "";

# Main loop starts here
while ($line = <temp_filehandle>)
{
	chop $line; # remove CR/LF

	# Print an alphabet soup for a progress bar	
	$new_first_char = substr($line,0,1);
	if ($new_first_char ne $first_char)
	{
		$first_char = $new_first_char;
		print "$first_char";
	}
	
	# Not sure if backticks will do the job here... it seems to be keeping file handles open
#	print "gamelog.pl -p $line -f $config_file -o $output_filename -a\n";
	`gamelog.pl -p $line -f $config_file -o $output_filename -a`;
}

print "\n";

# open the output file for writing, appending
if (!open(output_filehandle, ">>$output_filename")) 
{
	die "Can't open output file $output_filename\n";
}

add_html_footer();

close (output_filehandle);

close (temp_filehandle);

print "File $output_filename created.\n";
