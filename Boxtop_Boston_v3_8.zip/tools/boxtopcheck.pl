# ===============================================================
# 
# boxtopcheck.pl
#
# (c) 2010-2014 Michael Hamel
#
# This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License. To view a copy of this license, visit # http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.
#
# Version history
# 04/23/2011  1.0  MH  Initial version, improved combination of seasoncheck.pl and boxcrosscheck.pl, first used with Archive 1.5
# 05/11/2011  1.1  MH  Skip players with 0 minutes played in a game
# 05/21/2011  1.2  MH  Add sources, cleanup inventory by replacing "N"s with blanks, add page title option
# 05/24/2011  1.3  MH  Optional support for reading in a .csv file with season stats for additional cross-checking
# 06/12/2011  1.4  MH  Added check for team pts = 2*FG + FT + 3PTFG
# 11/21/2011  1.5  MH  Option to check multiple teams based on a "league" file
# 03/08/2014  1.6  MH  Moved sources to right-most column in tables
# 06/18/2014  1.7  MH  Add index links and tweaks to format
#
# ===============================================================


#! usr/bin/perl
use Getopt::Std;

# Overall count of games, regular season + playoffs
my $game_count = 0;

# Set to "yes" to print games where a stat is missing; especially useful for cases like FGM, 
# FTM, PTS where we should have these stats for EVERY game but can be useful for any stat.
# BE SURE TO TURN ON THE ONES YOU WANT TO USE by searching the code
my $verbose_print = "yes";

# Use hashes for players - one entry per player
my %player_games_played;
my %player_fgm;
my %player_ftm;
my %player_fta;
my %player_fgm3;
my %player_fga3;
my %player_pf;
my %player_pts;
my %player_first_names;
my %player_last_names;
my %player_min = ();
my %player_fga = ();
my %player_reb = ();
my %player_ast = ();

my %current_game_counters = (minutes => 0, fgm => 0, fga => 0, ftm => 0, fta => 0, fgm3 => 0, fga3 => 0, pf => 0, pts => 0, min => 0, reb => 0, ast => 0, team_reb => 0, games => 0);


my %season_team_games_played;
my %season_team_fgm;
my %season_team_ftm;
my %season_team_fta;
my %season_team_fgm3;
my %season_team_fga3;
my %season_team_pf;
my %season_team_pts;
my %season_team_first_names;
my %season_team_last_names;
my %season_team_min = ();
my %season_team_fga = ();
my %season_team_reb = ();
my %season_team_team_reb = ();
my %season_team_ast = ();

my %season_stat_counters_games_played;
my %season_stat_counters_fgm;
my %season_stat_counters_ftm;
my %season_stat_counters_fta;
my %season_stat_counters_fgm3;
my %season_stat_counters_fga3;
my %season_stat_counters_pf;
my %season_stat_counters_pts;
my %season_stat_counters_min = ();
my %season_stat_counters_fga = ();
my %season_stat_counters_reb = ();
my %season_stat_counters_team_reb = ();
my %season_stat_counters_ast = ();


my %team_list = ();
my %playoff_team_list = ();

# Hashes for official stats for regular season and playoffs
my %BR_regular_player_games_played;
my %BR_regular_player_fgm;
my %BR_regular_player_ftm;
my %BR_regular_player_fta;
my %BR_regular_player_fgm3;
my %BR_regular_player_fga3;
my %BR_regular_player_pf;
my %BR_regular_player_pts;
my %BR_regular_player_first_names;
my %BR_regular_player_last_names;
my %BR_regular_player_min = ();
my %BR_regular_player_fga = ();
my %BR_regular_player_reb = ();
my %BR_regular_player_ast = ();

my %BR_playoffs_player_games_played;
my %BR_playoffs_player_fgm;
my %BR_playoffs_player_ftm;
my %BR_playoffs_player_fta;
my %BR_playoffs_player_fgm3;
my %BR_playoffs_player_fga3;
my %BR_playoffs_player_pf;
my %BR_playoffs_player_pts;
my %BR_playoffs_player_first_names;
my %BR_playoffs_player_last_names;
my %BR_playoffs_player_min = ();
my %BR_playoffs_player_fga = ();
my %BR_playoffs_player_reb = ();
my %BR_playoffs_player_ast = ();

my %BR_regular_team_fgm;
my %BR_regular_team_ftm;
my %BR_regular_team_fta;
my %BR_regular_team_fgm3;
my %BR_regular_team_fga3;
my %BR_regular_team_pf;
my %BR_regular_team_pts;
my %BR_regular_team_min;
my %BR_regular_team_fga;
my %BR_regular_team_reb;
my %BR_regular_team_ast;

my %BR_playoffs_team_fgm;
my %BR_playoffs_team_ftm;
my %BR_playoffs_team_fta;
my %BR_playoffs_team_fgm3;
my %BR_playoffs_team_fga3;
my %BR_playoffs_team_pf;
my %BR_playoffs_team_pts;
my %BR_playoffs_team_min;
my %BR_playoffs_team_fga;
my %BR_playoffs_team_reb;
my %BR_playoffs_team_ast;

my $regular_season_issue = "";
my $playoff_issue = "";

my $page_title;

my $checking_season_stats_file = "no";
my $season_stats_filename;

my $number_of_regular_season_games = 0;
my $team_full_name = "";

# init to defaults
my %config_options = (
	inventory => on,
	threeptfg => off,
);

# ===============================================================

sub usage
{
    print "Create BOXTOP report based on a boxtop file.\n";
    print "1. Cross-checks each box score for correctness\n";
    print "2. Tabulates season totals for each player (in the season stats file)\n";
    print "3. Creates game inventory\n";
    print "\n";
    print "Output is written in .htm format\n";
    
    print "\n";
    print "\nUSAGE:\n";
    print "boxtopcheck.pl [-i inputfilename] [-o outputfilename] [-t page title]\n";
    print "               [-s season stats file | -n numberofregularseasongames]\n";
    print "               [-g [on|off] check 3 point FG] [-v inventory on|off]\n";
    print "\n";
    print " Defaults:\n";
    print "  Input file: input.csv   Output file: seasonoutput.htm\n";
    print "  Page title: 'inputfilename', 3PT FG OFF, Inventory ON\n";
    print "\n";
    print " If 'season stats file' or 'numberofregularseasongames' is provided, output\n";
    print "  is split between regular season and playoffs, season totals are calculated,\n";
    print "  and a game inventory is created.\n\n";
   
}
# end of sub usage()

# ===============================================================

# ===============================================================
# 
# parse_csv_line()
#
# Parses one line of a csv file and fills an array to return to caller.
#
# Input:
#
# Output:
#  Array that contains each element of the csv line.
#
# ===============================================================
sub parse_csv_line(@)
{
    ($line) = @_;

        # Note: If we don't declare this here, we end up re-using previously
    #       declared variable on our next trip through here!
        my @csv_elements;

        # trick - add a comma at the end of the line in place of the CR
        # makes searching easier...
        chomp($line);
        $line = join(",",$line,"");
    
        while ((my $next_comma = index($line,",")) >= 0)
        {
            # Grab next column header.
            push @csv_elements, substr($line,0,$next_comma);

            $line = substr($line,($next_comma+1),length($line));
        }
    
        return(@csv_elements);
}
# end of sub parse_csv_line()


# =====================================================================

sub clear_team_stats(\%)
{
    my %stats = ${shift()};

	print "Here @{[%stats]}\n";
    
	foreach (keys %stats)
 	{
	 	$aa{$_} = 0;
	}

	print "Here2 @{[%stats]}\n";
	
}
# end of sub clear_team_stats()

# =====================================================================

# helper function for dump_stats_summary_to_file()
sub check_and_print_stat_summary($$$$)
{
	$our_stat = $_[0];
	$official_stat = $_[1];
	$number_of_games = $_[2];
	$number_of_games_where_this_stat_is_available = $_[3];
	
	if ($our_stat eq $official_stat)
	{
		print output_filehandle "<td align = \"right\">$our_stat<\/td>";
	}
	elsif ($number_of_games eq $number_of_games_where_this_stat_is_available)
	{
		# This statistic SHOULD be correct since we have full season data for this statistic.
		# Highlight the error in red and print the good data.
		print output_filehandle "<td align = \"right\" ><font color=red>$our_stat<\/font> ($official_stat)<\/td>";
	}
	else
	{
		# Just print the data in blue because we have incomplete data
		print output_filehandle "<td align = \"right\" ><font color=blue>$our_stat<\/font><\/td>";
	}
}	

# =====================================================================

sub dump_stats_summary_to_file($$)
{
	$preamble = $_[0];
	$teamid = $_[1];
	
	if ($preamble eq "regular season")
	{
		$games_hashref = \%BR_regular_player_games_played;
		$fgm_hashref = \%BR_regular_player_fgm;
		$fga_hashref = \%BR_regular_player_fga;
		$ftm_hashref = \%BR_regular_player_ftm;
		$fta_hashref = \%BR_regular_player_fta;
		$fgm3_hashref = \%BR_regular_player_fgm3;
		$fga3_hashref = \%BR_regular_player_fga3;
		$pf_hashref = \%BR_regular_player_pf;
		$pts_hashref = \%BR_regular_player_pts;
		$first_names_hashref = \%BR_regular_player_first_names;
		$second_names_hashref = \%BR_regular_player_second_names;
		$min_hashref = \%BR_regular_player_min;
		$reb_hashref = \%BR_regular_player_reb;
		$ast_hashref = \%BR_regular_player_ast;
	}
	else
	{
		$games_hashref = \%BR_playoffs_player_games_played;
		$fgm_hashref = \%BR_playoffs_player_fgm;
		$fga_hashref = \%BR_playoffs_player_fga;
		$ftm_hashref = \%BR_playoffs_player_ftm;
		$fta_hashref = \%BR_playoffs_player_fta;
		$fgm3_hashref = \%BR_playoffs_player_fgm3;
		$fga3_hashref = \%BR_playoffs_player_fga3;
		$pf_hashref = \%BR_playoffs_player_pf;
		$pts_hashref = \%BR_playoffs_player_pts;
		$first_names_hashref = \%BR_playoffs_player_first_names;
		$second_names_hashref = \%BR_playoffs_player_second_names;
		$min_hashref = \%BR_playoffs_player_min;
		$reb_hashref = \%BR_playoffs_player_reb;
		$ast_hashref = \%BR_playoffs_player_ast;
	}
	
	print output_filehandle "<p><h3>$teamid $preamble statistics<\/h3>";
    print output_filehandle "<table>\n";
	
	print output_filehandle "<tr>";
	print output_filehandle "<td align = \"left\">Name<\/td>";
#	print output_filehandle "<td align = \"left\">PlayerId<\/td>";
	print output_filehandle "<td align = \"center\">Games<\/td>";
	print output_filehandle "<td align = \"center\">MIN<\/td>";
	print output_filehandle "<td align = \"center\">FGM<\/td>";
	print output_filehandle "<td align = \"center\">FGA<\/td>";
	print output_filehandle "<td align = \"center\">FTM<\/td>";
	print output_filehandle "<td align = \"center\">FTA<\/td>";
	if ($config_options{threeptfg} eq "on")
	{
		print output_filehandle "<td align = \"center\">3FGM<\/td>";
		print output_filehandle "<td align = \"center\">3FGA<\/td>";
	}
	print output_filehandle "<td align = \"center\">REB<\/td>";
	print output_filehandle "<td align = \"center\">AST<\/td>";
	print output_filehandle "<td align = \"center\">PF<\/td>";
	print output_filehandle "<td align = \"center\">PTS<\/td>";
	print output_filehandle "<td align = \"center\">TEAM REB<\/td>";
	print output_filehandle "</tr>\n";	
	
	foreach $value (sort keys %player_fgm)
	{
		@id_info = split(/-/,$value);
		$my_id = $id_info[0];
		$my_team_id = $id_info[1];
		if ($my_team_id eq $teamid)
		{
			print output_filehandle "<tr onmouseover=\"this.style.backgroundColor = '#CCCCCC';\" onmouseout=\"this.style.backgroundColor = '#f7f6eb';\">";
			print output_filehandle "<td align = \"left\">$player_first_names{$value} $player_last_names{$value}<\/td>";
#			print output_filehandle "<td align = \"left\">$my_id<\/td>"; # DEBUG: can print $value here to see team name too
			
			check_and_print_stat_summary($player_games_played{$value},$$games_hashref{$value},0,0); # we always have the right number of games
			check_and_print_stat_summary($player_min{$value},$$min_hashref{$value},$season_team_games_played{$teamid},$season_stat_counters_min{$teamid});
			check_and_print_stat_summary($player_fgm{$value},$$fgm_hashref{$value},$season_team_games_played{$teamid},$season_stat_counters_fgm{$teamid});
			check_and_print_stat_summary($player_fga{$value},$$fga_hashref{$value},$season_team_games_played{$teamid},$season_stat_counters_fga{$teamid});
			check_and_print_stat_summary($player_ftm{$value},$$ftm_hashref{$value},$season_team_games_played{$teamid},$season_stat_counters_ftm{$teamid});
			check_and_print_stat_summary($player_fta{$value},$$fta_hashref{$value},$season_team_games_played{$teamid},$season_stat_counters_fta{$teamid});
			if ($config_options{threeptfg} eq "on")
			{	
				check_and_print_stat_summary($player_fgm3{$value},$$fgm3_hashref{$value},$season_team_games_played{$teamid},$season_stat_counters_fgm3{$teamid});
				check_and_print_stat_summary($player_fga3{$value},$$fga3_hashref{$value},$season_team_games_played{$teamid},$season_stat_counters_fga3{$teamid});
			}
			check_and_print_stat_summary($player_reb{$value},$$reb_hashref{$value},$season_team_games_played{$teamid},$season_stat_counters_reb{$teamid});
			check_and_print_stat_summary($player_ast{$value},$$ast_hashref{$value},$season_team_games_played{$teamid},$season_stat_counters_ast{$teamid});
			check_and_print_stat_summary($player_pf{$value},$$pf_hashref{$value},$season_team_games_played{$teamid},$season_stat_counters_pf{$teamid});
			check_and_print_stat_summary($player_pts{$value},$$pts_hashref{$value},$season_team_games_played{$teamid},$season_stat_counters_pts{$teamid});
			
			print output_filehandle "<td align = \"right\"><\/td>";
			print output_filehandle "</tr>\n";
	
		}
	}

# my %season_stat_counters = (minutes => 0, fgm => 0, fga => 0, ftm => 0, fta => 0, pf => 0, pts => 0, min => 0, reb => 0, ast => 0, team_reb => 0, games => 0);
# my %season_team_stats = (minutes => 0, fgm => 0, fga => 0, ftm => 0, fta => 0, pf => 0, pts => 0, min => 0, reb => 0, ast => 0, team_reb => 0, games => 0);

	# TBD - need better data structures so we're not doing this messy code
	if ($preamble eq "regular season")
	{
		$tm_fgm = $BR_regular_team_fgm{$teamid};
		$tm_ftm = $BR_regular_team_ftm{$teamid};
		$tm_fta = $BR_regular_team_fta{$teamid};
		$tm_fgm3 = $BR_regular_team_fgm3{$teamid};
		$tm_fga3 = $BR_regular_team_fga3{$teamid};
		$tm_pf = $BR_regular_team_pf{$teamid};
		$tm_pts = $BR_regular_team_pts{$teamid};
		$tm_min = $BR_regular_team_min{$teamid};
		$tm_fga = $BR_regular_team_fga{$teamid};
		$tm_reb = $BR_regular_team_reb{$teamid};
		$tm_ast = $BR_regular_team_ast{$teamid}	;
	}
	else
	{
		$tm_fgm = $BR_playoffs_team_fgm{$teamid};
		$tm_ftm = $BR_playoffs_team_ftm{$teamid};
		$tm_fta = $BR_playoffs_team_fta{$teamid};
		$tm_fgm3 = $BR_playoffs_team_fgm3{$teamid};
		$tm_fga3 = $BR_playoffs_team_fga3{$teamid};
		$tm_pf = $BR_playoffs_team_pf{$teamid};
		$tm_pts = $BR_playoffs_team_pts{$teamid};
		$tm_min = $BR_playoffs_team_min{$teamid};
		$tm_fga = $BR_playoffs_team_fga{$teamid};
		$tm_reb = $BR_playoffs_team_reb{$teamid};
		$tm_ast = $BR_playoffs_team_ast{$teamid};	
	}
		

	print output_filehandle "<tr>";
	print output_filehandle "<td align = \"left\"><b>TEAM<\/b><\/td>";
	check_and_print_stat_summary($season_team_games_played{$teamid},$season_team_games_played{$teamid},0,0); # we always have the right number of games
	check_and_print_stat_summary($season_team_min{$teamid},$tm_min,$season_team_games_played{$teamid},$season_stat_counters_min{$teamid});
	check_and_print_stat_summary($season_team_fgm{$teamid},$tm_fgm,$season_team_games_played{$teamid},$season_stat_counters_fgm{$teamid});
	check_and_print_stat_summary($season_team_fga{$teamid},$tm_fga,$season_team_games_played{$teamid},$season_stat_counters_fga{$teamid});
	check_and_print_stat_summary($season_team_ftm{$teamid},$tm_ftm,$season_team_games_played{$teamid},$season_stat_counters_ftm{$teamid});
	check_and_print_stat_summary($season_team_fta{$teamid},$tm_fta,$season_team_games_played{$teamid},$season_stat_counters_fta{$teamid});
	if ($config_options{threeptfg} eq "on")	
	{
		check_and_print_stat_summary($season_team_fgm3{$teamid},$tm_fgm3,$season_team_games_played{$teamid},$season_stat_counters_fgm3{$teamid});
		check_and_print_stat_summary($season_team_fga3{$teamid},$tm_fga3,$season_team_games_played{$teamid},$season_stat_counters_fga3{$teamid});
	}
	check_and_print_stat_summary($season_team_reb{$teamid},$tm_reb,$season_team_games_played{$teamid},$season_stat_counters_reb{$teamid});
	check_and_print_stat_summary($season_team_ast{$teamid},$tm_ast,$season_team_games_played{$teamid},$season_stat_counters_ast{$teamid});
	check_and_print_stat_summary($season_team_pf{$teamid},$tm_pf,$season_team_games_played{$teamid},$season_stat_counters_pf{$teamid});
	check_and_print_stat_summary($season_team_pts{$teamid},$tm_pts,$season_team_games_played{$teamid},$season_stat_counters_pts{$teamid});
	print output_filehandle "<td align = \"right\">$season_team_team_reb{$teamid}<\/td>"; # exception case for now
	print output_filehandle "</tr>\n";

	print output_filehandle "<tr>";
	print output_filehandle "<td align = \"left\"style = \"font-size:70%\;\"><b>Games Available<\/b><\/td>";
	print output_filehandle "<td align = \"right\">$season_team_games_played{$teamid}<\/td>";
	print output_filehandle "<td align = \"right\">$season_stat_counters_min{$teamid}<\/td>";
	print output_filehandle "<td align = \"right\">$season_stat_counters_fgm{$teamid}<\/td>";
	print output_filehandle "<td align = \"right\">$season_stat_counters_fga{$teamid}<\/td>";
	print output_filehandle "<td align = \"right\">$season_stat_counters_ftm{$teamid}<\/td>";
	print output_filehandle "<td align = \"right\">$season_stat_counters_fta{$teamid}<\/td>";
	if ($config_options{threeptfg} eq "on")
	{
		print output_filehandle "<td align = \"right\">$season_stat_counters_fgm3{$teamid}<\/td>";
		print output_filehandle "<td align = \"right\">$season_stat_counters_fga3{$teamid}<\/td>";
	}
	print output_filehandle "<td align = \"right\">$season_stat_counters_reb{$teamid}<\/td>";
	print output_filehandle "<td align = \"right\">$season_stat_counters_ast{$teamid}<\/td>";
	print output_filehandle "<td align = \"right\">$season_stat_counters_pf{$teamid}<\/td>";
	print output_filehandle "<td align = \"right\">$season_stat_counters_pts{$teamid}<\/td>";
	print output_filehandle "<td align = \"right\">$season_stat_counters_team_reb{$teamid}<\/td>";
	print output_filehandle "</tr>\n";

    print output_filehandle "<\/table>\n";
    
	print output_filehandle "<p><b>Games Available<\/b> denotes the number of games for which that statistic is available for every player who played in the game.\n";
	print output_filehandle "<br>For a specific game, some stats may be partially available, and complete data may be available for some players but not others.\n";
	print output_filehandle "<br>Incomplete season totals are displayed in <font color=blue>blue<\/font>.\n";
	print output_filehandle "<br>Known deviations from Basketball-Reference.com are displayed in <font color=red>red<\/font> with their \"official\" total in ().\n";

    if ($preamble eq "regular season")
    {
        if (length($regular_season_issue) > 0)
        {
            print output_filehandle "<p>Note: $regular_season_issue\n";
        }
    }
    else
    {
        if (length($playoff_issue) > 0)
        {
            print output_filehandle "<p>Note: $playoff_issue\n";
        }
    }

	print output_filehandle "<p><hr>\n";

}
# end of sub dump_stats_summary_to_file()

# ===============================================================

$inventory_yes_global_string = "<td align = \"left\">Y<\/td>";
$inventory_missing_global_string = "<td align = \"left\"> <\/td>"; # used to print N

# Game inventory function, displays a single game
# TBD - For now, the current_game_counters are for both teams in a given game, so we either declare
#       a stat complete for both teams or neither. It would be better to do the home and road teams
#       separately, so we can declare one team complete and the other not complete, as required.
sub gamelog_to_file()
{
    print output_filehandle "<tr onmouseover=\"this.style.backgroundColor = '#CCCCCC';\" onmouseout=\"this.style.backgroundColor = '#f7f6eb';\">";
    print output_filehandle "<td align = \"left\">$game_date<\/td>";
    print output_filehandle "<td align = \"left\">$road_team_name<\/td>";
    print output_filehandle "<td align = \"left\">$home_team_name<\/td>";
    
    # If the counters are all at zero, this game probably does not have any stats at all, so skip the analysis
    
    if (($current_game_counters{minutes} == $current_game_counters{games}) && ($current_game_counters{games} > 0))
    {
	    $season_stat_counters_min{$road_team_name}++;
	    $season_stat_counters_min{$home_team_name}++;
	    print output_filehandle $inventory_yes_global_string;
	}
	else
	{
	    print output_filehandle $inventory_missing_global_string;
	}
    if (($current_game_counters{fgm} == $current_game_counters{games}) && ($current_game_counters{games} > 0))
    {
	    $season_stat_counters_fgm{$road_team_name}++;
	    $season_stat_counters_fgm{$home_team_name}++;
	    print output_filehandle $inventory_yes_global_string;
	}
	else
	{
	    print output_filehandle $inventory_missing_global_string;
		if ($verbose_print eq "yes")
		{
    		print "FGM missing from game $game_count ($game_date)\n";
		}
	}
	
    if (($current_game_counters{fga} == $current_game_counters{games}) && ($current_game_counters{games} > 0))
    {
	    $season_stat_counters_fga{$road_team_name}++;
	    $season_stat_counters_fga{$home_team_name}++;
	    print output_filehandle $inventory_yes_global_string;
	}
	else
	{
	    print output_filehandle $inventory_missing_global_string;
	}
	
    if (($current_game_counters{ftm} == $current_game_counters{games}) && ($current_game_counters{games} > 0))
    {
	    $season_stat_counters_ftm{$road_team_name}++;
	    $season_stat_counters_ftm{$home_team_name}++;
	    print output_filehandle $inventory_yes_global_string;
	}
	else
	{
	    print output_filehandle $inventory_missing_global_string;
	    if ($verbose_print eq "yes")
    	{
	    	print "FTM missing from game $game_count ($game_date)\n";
    	}
	}
    	
    if (($current_game_counters{fta} == $current_game_counters{games}) && ($current_game_counters{games} > 0))
    {
	    $season_stat_counters_fta{$road_team_name}++;
	    $season_stat_counters_fta{$home_team_name}++;
	    print output_filehandle $inventory_yes_global_string;
	}
	else
	{
	    print output_filehandle $inventory_missing_global_string;
	}

	if ($config_options{threeptfg} eq "on")	
    {
	    if (($current_game_counters{fgm3} == $current_game_counters{games}) && ($current_game_counters{games} > 0))
	    {
		    $season_stat_counters_fgm3{$road_team_name}++;
		    $season_stat_counters_fgm3{$home_team_name}++;
		    print output_filehandle $inventory_yes_global_string;
		}
		else
		{
		    print output_filehandle $inventory_missing_global_string;
		    if ($verbose_print eq "yes")
	    	{
		    	print "3FGM missing from game $game_count ($game_date)\n";
	    	}
		}
	    	
	    if (($current_game_counters{fga3} == $current_game_counters{games}) && ($current_game_counters{games} > 0))
	    {
		    $season_stat_counters_fga3{$road_team_name}++;
		    $season_stat_counters_fga3{$home_team_name}++;
		    print output_filehandle $inventory_yes_global_string;
		}
		else
		{
		    print output_filehandle $inventory_missing_global_string;
		}
	}
		
    if (($current_game_counters{pf} == $current_game_counters{games}) && ($current_game_counters{games} > 0))
    {
	    $season_stat_counters_pf{$road_team_name}++;
	    $season_stat_counters_pf{$home_team_name}++;
	    print output_filehandle $inventory_yes_global_string;
	}
	else
	{
	    print output_filehandle $inventory_missing_global_string;
	}
    if (($current_game_counters{pts} == $current_game_counters{games}) && ($current_game_counters{games} > 0))
    {
	    $season_stat_counters_pts{$road_team_name}++;
	    $season_stat_counters_pts{$home_team_name}++;
	    print output_filehandle $inventory_yes_global_string
	}
	else
	{
	    print output_filehandle $inventory_missing_global_string;
		if ($verbose_print eq "yes")
		{
	    	print "PTS missing from game $game_count ($game_date)\n";
		}
	}
	
    if (($current_game_counters{reb} == $current_game_counters{games}) && ($current_game_counters{games} > 0))
    {
	    $season_stat_counters_reb{$road_team_name}++;
	    $season_stat_counters_reb{$home_team_name}++;
	    print output_filehandle $inventory_yes_global_string;
	}
	else
	{
	    print output_filehandle $inventory_missing_global_string;
	}
    if (($current_game_counters{ast} == $current_game_counters{games}) && ($current_game_counters{games} > 0))
    {
	    $season_stat_counters_ast{$road_team_name}++;
	    $season_stat_counters_ast{$home_team_name}++;
	    print output_filehandle $inventory_yes_global_string;
	}
	else
	{
	    print output_filehandle $inventory_missing_global_string;
	}

	if ($game_arena ne "")
	{
	    print output_filehandle $inventory_yes_global_string;
	}
	else
	{
	    print output_filehandle $inventory_missing_global_string;
	}
	
	if ($game_attendance ne "")
	{
	    print output_filehandle $inventory_yes_global_string;
	}
	else
	{
	    print output_filehandle $inventory_missing_global_string;
	}
	
	if ($game_starttime ne "")
	{
	    print output_filehandle $inventory_yes_global_string;
	}
	else
	{
	    print output_filehandle $inventory_missing_global_string;
	}

    print output_filehandle "<td align = \"left\">$game_ref_count<\/td>";
	
	# End this line of output
    print output_filehandle "<td align = \"left\" style = \"font-size:70%\;\">$game_title<\/td>";
    print output_filehandle "<td align = \"left\" style = \"font-size:70%\;\">$game_sources<\/td>";
    print output_filehandle "<\/tr>\n";
}

# end of sub gamelog_to_file()

# ===============================================================

sub add_header()
{
print output_filehandle "<html>\n<head>\n";
print output_filehandle "<style type=\"text/css\">\n<!--\n";
print output_filehandle "h1 { font-family: Georgia, Verdana, Arial, sans-serif;\n   }\n";
print output_filehandle "h2 { font-family: Georgia, Verdana, Arial,  sans-serif;\n   }\n";
print output_filehandle "h3 { font-family: Georgia, Verdana, Arial,  sans-serif;\n   }\n";
print output_filehandle "h4 { font-family: Verdana, Arial,  sans-serif;\n   }\n";
print output_filehandle "td { font-family: Georgia, Verdana, Arial,  sans-serif;\n   }\n";
print output_filehandle "-->\n<\/style>\n";
print output_filehandle "<meta name=\"description\" content=\"Historical NBA Box Scores\">\n";
print output_filehandle "<meta name=\"keywords\" content=\"Boston Celtics, Bill Russell, Red Auerbach, NBA, Box Scores, Boxscores, Box Score, Boxscore\">\n";
print output_filehandle "<title>BOXTOP Report - $page_title<\/title>\n";
print output_filehandle "<\/head>\n";
}
# end of sub add_header()

# ===============================================================

sub add_footer()
{
	($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);

	print output_filehandle "<hr><p>This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License.<br>To view a copy of this license, visit <a href=\"http:\/\/creativecommons.org\/licenses\/by-nc-sa\/3.0\/\">http:\/\/creativecommons.org\/licenses\/by-nc-sa\/3.0\/<\/a>\n";
	printf output_filehandle "<p>Web page created at %02d:%02d:%02d on %02s\/%02d\/%4d using boxtopcheck.pl based on <a href=\"http://www.michaelhamel.net/boxtop-project\">boxtop format data<\/a>, (c) 2010-2014 Michael Hamel.\n",$hour,$min,$sec,$mon+1,$mday,$year+1900;
	print output_filehandle "<p>Citation: The information used here was obtained free of charge from and is copyrighted by the <a href=\"http://www.michaelhamel.net/boxtop-project\">Basketball BOXTOP Project<\/a>.\n";

}
# end of sub add_footer()

# =====================================================================

sub cross_check($\%)
{
	my $team_all = shift;
	my $param_hash = shift;
	my %player_stats = %$param_hash;
		    
#    $value = $team_stats{rteam};
    @stats_line = parse_csv_line($team_all);
	$team_min = $stats_line[2];
	$team_fgm = $stats_line[3];
	$team_fga = $stats_line[4];
	$team_ftm = $stats_line[5];
	$team_fta = $stats_line[6];
	$team_fgm3 = $stats_line[7];
	$team_fga3 = $stats_line[8];
	$team_reb = $stats_line[11];
	$team_ast = $stats_line[12];
	$team_pf = $stats_line[13];
	$team_pts = $stats_line[9];
	
	$player_min = 0;
	$player_fgm = 0;
	$player_fga = 0;
	$player_ftm = 0;
	$player_fta = 0;
	$player_fgm3 = 0;
	$player_fga3 = 0;
	$player_reb = 0;
	$player_ast = 0;
	$player_pf = 0;
	$player_pts = 0;
	
	# We want to ignore any mismatches if a column is not complete.
	# We'll declare a column as "not complete" if 3 or more players have no data for a particular statistic.
	# This way, we catch cases where we missed entering a particular stat for 1 or 2 players, but
	# cover cases such as rebounds where in many box scores we have a team total and just a couple of leaders.	
	$missing_min = 0;
	$missing_fgm = 0;
	$missing_fga = 0;
	$missing_ftm = 0;
	$missing_fta = 0;
	$missing_fgm3 = 0;
	$missing_fga3 = 0;
	$missing_reb = 0;
	$missing_ast = 0;
	$missing_pf = 0;
	$missing_pts = 0;
		    
    foreach $value (values %player_stats)
    {
#   	print $value;
    	@stats_line = parse_csv_line($value);

    	$min = $stats_line[6];
    	$fgm = $stats_line[7];
    	$fga = $stats_line[8];
    	$ftm = $stats_line[9];
    	$fta = $stats_line[10];
    	$fgm3 = $stats_line[11];
    	$fga3 = $stats_line[12];
    	$pts = $stats_line[13];
    	$reb = $stats_line[15];
    	$ast = $stats_line[16];
    	$pf = $stats_line[17];

    	if ($min eq "")
		{
			$missing_min++;
		}
    	if ($fgm eq "")
		{
			$missing_fgm++;
		}
    	if ($fga eq "")
		{
			$missing_fga++;
		}
    	if ($ftm eq "")
		{
			$missing_ftm++;
		}
    	if ($fta eq "")
		{
			$missing_fta++;
		}
    	if ($fgm3 eq "")
		{
			$missing_fgm3++;
		}
    	if ($fga3 eq "")
		{
			$missing_fga3++;
		}
    	if ($reb eq "")
		{
			$missing_reb++;
		}
    	if ($ast eq "")
		{
			$missing_ast++;
		}
    	if ($pf eq "")
		{
			$missing_pf++;
		}
    	if ($pts eq "")
		{
			$missing_pts++;
		}
    	
    	if ($pts != ($fgm * 2) + $fgm3 + $ftm)
		{
			print output_filehandle "<br>$date_of_game: Points mismatch ($stats_line[4] $stats_line[5] FGM=$fgm, FTM=$ftm, 3FGM=$fgm3, PTS=$pts)\n";
		}
		
		# Check for mistakes where player made more shots than attempted.
		# Skip the check if we do not have the number of attempts.
		if (($fgm > $fga) && ($fga ne ""))
		{
			print output_filehandle "<br>$date_of_game: FG mismatch ($stats_line[4] $stats_line[5] FGM=$fgm cannot be > FGA=$fga)\n";
		}
		
		if (($ftm > $fta) && ($fta ne ""))
		{
			print output_filehandle "<br>$date_of_game: FT mismatch ($stats_line[4] $stats_line[5] FTM=$ftm cannot be > FTA=$fta)\n";
		}

		if (($fgm3 > $fga3) && ($fga3 ne ""))
		{
			print output_filehandle "<br>$date_of_game: 3FG mismatch ($stats_line[4] $stats_line[5] 3FGM=$fgm3 cannot be > 3FGA=$fga3)\n";
		}

		if ($fgm3 > $fgm)
		{
			print output_filehandle "<br>$date_of_game: 3FG mismatch ($stats_line[4] $stats_line[5] 3FGM=$fgm3 cannot be > Total FGM=$fgm)\n";
		}

		$player_min +=$min;
		$player_fgm +=$fgm;
		$player_fga +=$fga;
		$player_ftm +=$ftm;
		$player_fta +=$fta;
		$player_fgm3 +=$fgm3;
		$player_fga3 +=$fga3;
		$player_reb +=$reb;
		$player_ast +=$ast;
		$player_pf +=$pf;
		$player_pts +=$pts;
	}		
	
	if ($stats_line[1] eq "rteam")
	{
		$team_name_to_print = $road_team_name;
	}
	else
	{
		$team_name_to_print = $home_team_name;
	}

	
	if (($team_min != $player_min) && ($missing_min < 3))
	{
		print output_filehandle "<br>$date_of_game: $team_name_to_print Team MIN mismatch (Team=$team_min, Players=$player_min)\n";
	}
	if (($team_fgm != $player_fgm) && ($missing_fgm < 3))
	{
		print output_filehandle "<br>$date_of_game: $team_name_to_print Team FGM mismatch (Team=$team_fgm, Players=$player_fgm)\n";
	}
	if (($team_fga != $player_fga) && ($missing_fga < 3))
	{
		print output_filehandle "<br>$date_of_game: $team_name_to_print Team FGA mismatch (Team=$team_fga, Players=$player_fga)\n";
	}
	if (($team_ftm != $player_ftm) && ($missing_ftm < 3))
	{
		print output_filehandle "<br>$date_of_game: $team_name_to_print Team FTM mismatch (Team=$team_ftm, Players=$player_ftm)\n";
	}
	if (($team_fta != $player_fta) && ($missing_fta < 3))
	{
		print output_filehandle "<br>$date_of_game: $team_name_to_print Team FTA mismatch (Team=$team_fta, Players=$player_fta)\n";
	}
	if (($team_fgm3 != $player_fgm3) && ($missing_fgm3 < 3))
	{
		print output_filehandle "<br>$date_of_game: $team_name_to_print Team 3FGM mismatch (Team=$team_fgm3, Players=$player_fgm3)\n";
	}
	if (($team_fga3 != $player_fga3) && ($missing_fga3 < 3))
	{
		print output_filehandle "<br>$date_of_game: $team_name_to_print Team 3FGA mismatch (Team=$team_fga3, Players=$player_fga3)\n";
	}
	if (($team_reb != $player_reb) && ($missing_reb < 3))
	{
		print output_filehandle "<br>$date_of_game: $team_name_to_print Team REB mismatch (Team=$team_reb, Players=$player_reb)\n";
	}
	if (($team_ast != $player_ast) && ($missing_ast < 3))
	{
		print output_filehandle "<br>$date_of_game: $team_name_to_print Team AST mismatch (Team=$team_ast, Players=$player_ast)\n";
	}
	if (($team_pf != $player_pf) && ($missing_pf < 3))
	{
		print output_filehandle "<br>$date_of_game: $team_name_to_print Team PF  mismatch (Team=$team_pf, Players=$player_pf)\n";
	}
	if (($team_pts != $player_pts) && ($missing_pts < 3))
	{
		print output_filehandle "<br>$date_of_game: $team_name_to_print Team PTS mismatch (Team=$team_pts, Players=$player_pts)\n";
	}
	
	# Note that FGM = 2pt FGM + 3pt FGM, so just add one point per 3ptm
	if ($team_pts != ($team_fgm * 2) + $team_ftm + $team_fgm3)
	{
		print output_filehandle "<br>$date_of_game: $team_name_to_print Team PTS mismatch (Team=$team_pts, Team FGM=$team_fgm, FTM=$team_ftm, 3PT=$team_fgm3)\n";
	}
}
# end of sub cross_check()

# ===================================================================

sub check_and_report(@)
{
	$lines_read = $_[0];
	
    # Do the following checks
	# 1. Player totals do not equal team totals (requires stat for each player)\n";
	# 2. Player (or team) points do not match FGM*2 + FTM\n";
	# 3. Linescore total points do not equal sum of per period scores in linescore\n";
	# 4. Team total points do not match linescore total points\n";
	
	# Note that the line number printed is the final line number for this box score,
	# not the exact line where the error occurs.

	###############################################################################
	# Check 1:  Player totals do not equal team totals 
	# 
	# Check 2: Check individual player points: assumes that "FGM" = 2pt + "3pt FGM"
	#
	
	cross_check($team_stats{rteam},%road_player_stats);
	cross_check($team_stats{hteam},%home_player_stats);


	
	###############################################################################
	# Check 3: Linescore
	#
	@road_linescore = parse_csv_line($linescores{rteam});
	@home_linescore = parse_csv_line($linescores{hteam});
	
	$road_column_count = $#road_linescore - 1;
	$home_column_count = $#home_linescore - 1;
	if ($road_column_count != $home_column_count)
	{
		print output_filehandle "<br>$date_of_game: Linescore length mismatch (Road=$road_column_count, Home=$home_column_count)\n";
	}
	
	$period_score = 0;
    for ($cc=2; $cc<$road_column_count; $cc++)
	{
    	$period_score += $road_linescore[$cc];
	}
	$road_final_score = $road_linescore[$road_column_count+1];
	if (($road_final_score != $period_score) && ($period_score > 0)) # supress if we don't have period scores
	{
		print output_filehandle "<br>$date_of_game: $road_team_name Linescore mismatch (Total=$road_final_score, period total=$period_score)\n";
	}

	$period_score = 0;
    for ($cc=2; $cc<$home_column_count; $cc++)
	{
    	$period_score += $home_linescore[$cc];
	}
	$home_final_score = $home_linescore[$home_column_count+1];
	if (($home_final_score != $period_score)  && ($period_score > 0)) # supress if we don't have period scores
	{
		print output_filehandle "<br>$date_of_game: $home_team_name Linescore mismatch (Total=$home_final_score, period total=$period_score)\n";
	}

	
		###############################################################################
	# Check 4: Team total points do not match linescore total points
	#
	# Uses $road_final_score and $home_final_score from Check 3.
	#
	$road_players_total_score = 0;
    foreach $value (values %road_player_stats)
    {
#   	print $value;
    	@stats_line = parse_csv_line($value);
    	$road_players_total_score += $stats_line[13];
	}
	if ($road_final_score != $road_players_total_score)
	{
		print output_filehandle "<br>$date_of_game: $road_team_name score mismatch (Boxscore=$road_final_score, Sum of players=$road_players_total_score)\n";
	}

	$home_players_total_score = 0;
    foreach $value (values %home_player_stats)
    {
#   	print $value;
    	@stats_line = parse_csv_line($value);
    	$home_players_total_score += $stats_line[13];
	}
	if ($home_final_score != $home_players_total_score)
	{
		print output_filehandle "<br>$date_of_game: $home_team_name score mismatch (Boxscore=$home_final_score, Sum of players=$home_players_total_score)\n";
	}

	################ END OF CHECKS ################################################		
} 
# end of sub check_and_report()

# ===================================================================

sub crosscheck_boxscores()
{
	my $lines_read_from_input_file = 0;
	my $first_gamebxt_read = "no";
	
	# The general idea is to read in all stats for a given game, just like the following does,
	# but then do the cross-checks mentioned in the usage.
	
    print output_filehandle "<a href=\"\#BoxScoreIssues\">Known issues with box scores<\/a><br>\n";
    print output_filehandle "<a href=\"\#RegularSeasonTotals\">Celtics regular season statistics and known issues<\/a><br>\n";
    print output_filehandle "<a href=\"\#PlayoffSeasonTotals\">Celtics playoff statistics and known issues<\/a><br>\n";
    print output_filehandle "<a href=\"\#RegularSeasonInventory\">Regular Season Game Inventory<\/a><br>\n";
    print output_filehandle "<a href=\"\#PlayoffInventory\">Playoffs Game Inventory<\/a><br>\n";
	
    print output_filehandle "<a name=BoxScoreIssues><\/a>\n";
	print output_filehandle "<h3>Known issues with box scores<\/h3>\n";
		
	while ($line = <input_filehandle>)
	{
		$lines_read_from_input_file++;
		
	    # read until we read a "gamebxt" which tells us to loop back around to the next boxscore
	
	    # read until we read a "gamebxt" which tells us we're done with the previous boxscore
	    # but skip everything until after we read the first one
		if ($line =~ /^$start_of_boxscore/)
	    {
		    if ($first_gamebxt_read eq "no")
		   	{
			    # flip the flag, but ignore this line
			    $first_gamebxt_read = "yes";
			}		   	
			else
		    {
			    check_and_report($lines_read_from_input_file);
			}
	
	        # clear all hashes
	        %team_stats = ();
	        %linescores = ();
	        %road_player_stats = ();
	        %home_player_stats = ();
	    }
	    elsif ($line =~ /^version/)
	    {
	        # ignore
	    }
	    elsif ($line =~ /^info/)
	    {
	        # split the line
	        @this_line_array = parse_csv_line($line);
	        
	        # grab date
	        if ($this_line_array[1] eq "date")
	        {
	            $date_of_game = $this_line_array[2];
	        }
	        elsif ($this_line_array[1] eq "rteam")
	        {
	            $road_team_name = $this_line_array[2];
	        }
	        elsif ($this_line_array[1] eq "hteam")
	        {
	            $home_team_name = $this_line_array[2];
	        }
	    }
	    elsif ($line =~ /^coach/)
	    {
	        # ignore
	    }
	    elsif ($line =~ /^stat/)
	    {
	        # split the line and add to hash
	        $copyline = $line;
	        @this_line_array = parse_csv_line($line);
	        if ($this_line_array[1] eq "rteam")
	        {
	            $road_player_stats{$this_line_array[3]} = $copyline;
	        }
	        else
	        {
	            $home_player_stats{$this_line_array[3]} = $copyline;
	        }
	    }
	    elsif ($line =~ /^tstat/)
	    {
	        # split the line and add to hash
	        $copyline = $line;
	        @this_line_array = parse_csv_line($line);
	        $team_stats{$this_line_array[1]} = $copyline;
	    }
	    elsif ($line =~ /^linescore/)
	    {
	        # split the line and add to hash
	        $copyline = $line;
	        @this_line_array = parse_csv_line($line);
	        $linescores{$this_line_array[1]} = $copyline;
	    }   
	
	
	} # end of main loop
	
	# Process the last box score in the file
	check_and_report($lines_read_from_input_file);
} 
# end of sub crosscheck_boxscores()
	
# ===========================================================

# These should be considered "official" stats, which we will use to compare
# against the totals that we derive from our box scores.
sub extract_player_season_stats()
{
	# For now we're going to keep this simple and make some assumptions
	#
	# Assume that this season is 1955-56 or later, since that is when Basketball-Reference.com
	# starts listing statistics by team for players who played on multiple teams during a season.
	# This only affects regular season stats prior to 1955-56 since no transactions are allowed
	# during the playoffs. Otherwise, the sum of the player stats should = the team stats.
	#
	while ($line = <season_input_filehandle>)	
	{
	    if ($line =~ /^seasonstat/)
	    {
	        # split the line
	        @this_line_array = parse_csv_line($line);

	        $id = $this_line_array[2] . "-" . $team_full_name;
	        
	        if ($this_line_array[1] eq "regular")
	        {
		        # regular season
				$BR_regular_player_first_names{$id} = $this_line_array[3];
				$BR_regular_player_last_names{$id} = $this_line_array[4];
				$BR_regular_player_games_played{$id} = $this_line_array[5];
				$BR_regular_player_min{$id} = $this_line_array[6];
				$BR_regular_player_fgm{$id} = $this_line_array[7];
				$BR_regular_player_fga{$id} = $this_line_array[8];
				$BR_regular_player_ftm{$id} = $this_line_array[9];
				$BR_regular_player_fta{$id} = $this_line_array[10];
				$BR_regular_player_fgm3{$id} = $this_line_array[11];
				$BR_regular_player_fga3{$id} = $this_line_array[12];
				$BR_regular_player_pts{$id} = $this_line_array[13];
				# skip OREB for Russell era
				$BR_regular_player_reb{$id} = $this_line_array[15];
				$BR_regular_player_ast{$id} = $this_line_array[16];
				$BR_regular_player_pf{$id} = $this_line_array[17];
				# skip blocks, turnovers, steals, technicalfouls
				
				$BR_regular_team_min{$team_full_name}+=$BR_regular_player_min{$id};
				$BR_regular_team_fgm{$team_full_name}+=$BR_regular_player_fgm{$id};
				$BR_regular_team_fga{$team_full_name}+=$BR_regular_player_fga{$id};
				$BR_regular_team_ftm{$team_full_name}+=$BR_regular_player_ftm{$id};
				$BR_regular_team_fta{$team_full_name}+=$BR_regular_player_fta{$id};
				$BR_regular_team_fgm3{$team_full_name}+=$BR_regular_player_fgm3{$id};
				$BR_regular_team_fga3{$team_full_name}+=$BR_regular_player_fga3{$id};
				$BR_regular_team_pts{$team_full_name}+=$BR_regular_player_pts{$id};
				$BR_regular_team_reb{$team_full_name}+=$BR_regular_player_reb{$id};
				$BR_regular_team_ast{$team_full_name}+=$BR_regular_player_ast{$id};
				$BR_regular_team_pf{$team_full_name}+=$BR_regular_player_pf{$id};
	    	}
	    	else
	    	{
		    	# playoffs
				$BR_playoffs_player_first_names{$id} = $this_line_array[3];
				$BR_playoffs_player_last_names{$id} = $this_line_array[4];
				$BR_playoffs_player_games_played{$id} = $this_line_array[5];
				$BR_playoffs_player_min{$id} = $this_line_array[6];
				$BR_playoffs_player_fgm{$id} = $this_line_array[7];
				$BR_playoffs_player_fga{$id} = $this_line_array[8];
				$BR_playoffs_player_ftm{$id} = $this_line_array[9];
				$BR_playoffs_player_fta{$id} = $this_line_array[10];
				$BR_playoffs_player_fgm3{$id} = $this_line_array[11];
				$BR_playoffs_player_fga3{$id} = $this_line_array[12];
				$BR_playoffs_player_pts{$id} = $this_line_array[13];
				# skip OREB for Russell era
				$BR_playoffs_player_reb{$id} = $this_line_array[15];
				$BR_playoffs_player_ast{$id} = $this_line_array[16];
				$BR_playoffs_player_pf{$id} = $this_line_array[17];
				# skip blocks, turnovers, steals, technicalfouls
				
				$BR_playoffs_team_min{$team_full_name}+=$BR_playoffs_player_min{$id};
				$BR_playoffs_team_fgm{$team_full_name}+=$BR_playoffs_player_fgm{$id};
				$BR_playoffs_team_fga{$team_full_name}+=$BR_playoffs_player_fga{$id};
				$BR_playoffs_team_ftm{$team_full_name}+=$BR_playoffs_player_ftm{$id};
				$BR_playoffs_team_fta{$team_full_name}+=$BR_playoffs_player_fta{$id};
				$BR_playoffs_team_fgm3{$team_full_name}+=$BR_playoffs_player_fgm3{$id};
				$BR_playoffs_team_fga3{$team_full_name}+=$BR_playoffs_player_fga3{$id};
				$BR_playoffs_team_pts{$team_full_name}+=$BR_playoffs_player_pts{$id};
				$BR_playoffs_team_reb{$team_full_name}+=$BR_playoffs_player_reb{$id};
				$BR_playoffs_team_ast{$team_full_name}+=$BR_playoffs_player_ast{$id};
				$BR_playoffs_team_pf{$team_full_name}+=$BR_playoffs_player_pf{$id};
				
	    	}
    	}   
    	elsif ($line =~ /^info/)
    	{
	        # split the line
	        @this_line_array = parse_csv_line($line);
	        
	        # Grab team name
	        if ($this_line_array[1] eq "teamname")
	        {
		        $team_full_name = $this_line_array[2];
		        $team_list{$team_full_name} = 1;
	      	}
	        
	        if (($this_line_array[1] eq "wlrecord") && ($this_line_array[2] eq "playoffs"))
	        {
		        $playoff_team_list{$team_full_name} = 1;
	    	}
	  	}
    	elsif ($line =~ /^seasonteam/)
    	{
	        # split the line
	        @this_line_array = parse_csv_line($line);
	        
	        # Grab number of regular season games from the file
	        # seasonteam,regular,82,...
	        if ($this_line_array[1] eq "regular")
	        {
		        $number_of_regular_season_games = $this_line_array[2];
	    	}
	  	}	  	
    	# else, ignore the line 
	}
	
}
# end of sub extract_player_season_stats()

# ===========================================================

$start_of_boxscore = "gamebxt";

# default filenames
$input_filename = "input.csv";
$output_filename = "seasonoutput.htm";
$skip_season_checks = "no";

getopts('i:o:n:h:t:s:g:v:',\%cli_opt);


if (exists ($cli_opt{"i"}))
{
    $input_filename = $cli_opt{"i"};
}

if (exists ($cli_opt{"o"}))
{
    $output_filename = $cli_opt{"o"};
}

if (exists ($cli_opt{"v"}))
{
    $config_options{inventory} = lc($cli_opt{"v"});
}

if (exists ($cli_opt{"n"}))
{
	# note that if a season stats file is specified, the data in that file takes precedence
	$number_of_regular_season_games = $cli_opt{"n"}; 
}

if (exists ($cli_opt{"t"}))
{
	$page_title = $cli_opt{"t"};
}
else
{
	$page_title = "empty"; # will default to input filename
}

if (exists ($cli_opt{"s"}))
{
	$checking_season_stats_file = "yes";
	$season_stats_filename = $cli_opt{"s"};
}

if (exists ($cli_opt{"g"}))
{
	$config_options{threeptfg} = lc($cli_opt{"g"});
}

if (exists ($cli_opt{"h"}))
{
	usage();
	exit;
}

# open for reading
if (!open(input_filehandle, "$input_filename")) 
{
        die "Can't open input file $input_filename\n";
}

# open for writing, creating if needed
if (!open(output_filehandle, ">$output_filename")) 
{
        close(input_filehandle);
        die "Can't open output file $output_filename\n";
}

if ($checking_season_stats_file eq "yes")
{
	if (!open(season_input_filehandle, "$season_stats_filename"))
	{
		$checking_season_stats_file = "no";
		print "Unable to open $season_stats_filename\n";
	}
	else
	{
		extract_player_season_stats(); # this can also update $number_of_regular_season_games
		close(season_input_filehandle);
	}
}

# print "regular season:\n";
# print "@{[%team_list]}\n";
# print "playoffs:\n";
# print "@{[%playoff_team_list]}\n";

# Determine if we should exit before calculating season stats and do a game inventory
if ($number_of_regular_season_games == 0)
{
	$skip_season_checks = "skip";
}

if ($page_title eq "empty")
{
	$page_title = $input_filename;
}

add_header(); # page-title must be set before making this call
print output_filehandle "<h2>BOXTOP Report - $page_title<\/h2>\n";

print "Checking $input_filename...\n\n";

# do the cross-checks first, then close the file and reopen it
crosscheck_boxscores();

close(input_filehandle);

if ($skip_season_checks eq "skip")
{
	print "File $output_filename created - skipped season totals and game inventory.\n";
	exit;
}

if (!open(input_filehandle, "$input_filename")) 
{
    die "Can't open input file $input_filename\n";
	close(season_stats_filehandle);
}

my $lines_read_from_input_file = 0;
my $first_gamebxt_read = "no";

# clear all hashes
%player_fgm = ();
%player_ftm = ();
%player_fta = ();
%player_fgm3 = ();
%player_fga3 = ();
%player_pf = ();
%player_pts = ();
%player_games_played = ();
%player_first_names = ();
%player_last_names = ();
%player_min = ();
%player_fga = ();
%player_reb = ();
%player_ast = ();

$game_date = "";
$game_title = "";
$game_arena = "";
$game_attendance = "";
$game_starttime = "";
$game_sources = "";
$game_ref_count = 0;

if ($config_options{threeptfg} eq "on")
{
	$inventory_header = "<tr><td>Date<\/td><td>Road<\/td><td>Home<\/td><td>MIN<\/td><td>FGM<\/td><td>FGA<\/td><td>FTM<\/td><td>FTA<\/td><td>3FGM<\/td><td>3FGA<\/td><td>PF<\/td><td>PTS<\/td><td>REB<\/td><td>AST<\/td><td>Arena<\/td><td>Attendance<\/td><td>StartTime<\/td><td>Refs<\/td><td>Title<\/td><td>Sources<\/td><\/tr>\n";
}
else
{
	$inventory_header = "<tr><td>Date<\/td><td>Road<\/td><td>Home<\/td><td>MIN<\/td><td>FGM<\/td><td>FGA<\/td><td>FTM<\/td><td>FTA<\/td><td>PF<\/td><td>PTS<\/td><td>REB<\/td><td>AST<\/td><td>Arena<\/td><td>Attendance<\/td><td>StartTime<\/td><td>Refs<\/td><td>Title<\/td><td>Sources<\/td><\/tr>\n";
}	

if ($config_options{inventory} eq "on")
{
    print output_filehandle "<a name=RegularSeasonInventory><\/a>\n";
    
	print output_filehandle "<p><h3>Regular Season Game Inventory<\/h3><table>\n";
	print output_filehandle $inventory_header;
}

# main loop

while ($line = <input_filehandle>)
{
	$lines_read_from_input_file++;
	
    # read until we read a "gamebxt" which tells us to loop back around to the next boxscore
    # but skip everything until after we read the first one
    if ($first_gamebxt_read eq "no")
    {
	    if ($line =~ /^$start_of_boxscore/)
	    {
		    # flip the flag, but ignore this line
		    $first_gamebxt_read = "yes";
		    $game_count++;
		}
		# else just skip the line
	}			  
    elsif ($line =~ /^$start_of_boxscore/)
    {
	    # We're finished with the previous box score, so determine if we need to increment our team stat counters
	    # Note that the "games" field is set equal to the number of players in this game; the other values
	    # will be <= that number.
	    
	    # Start by logging this game
		if ($config_options{inventory} eq "on")
		{
			gamelog_to_file();	    
		}
	    
				
    	# The current game counters are no longer needed, so clear them to get ready for the next game
		foreach (keys %current_game_counters)
	 	{
		 	$current_game_counters{$_} = 0;
		}
		$game_date = "";
		$game_title = "";
		$game_arena = "";
		$game_attendance = "";
		$game_sources = "";
		$game_starttime = "";
		$game_ref_count = 0;

	    # we init game_count to 1 but do not increment it until AFTER processing the first game
	    # so when we've processed 50 games we'll be here with $game_count = 50 (or we will have exited
	    # this loop entirely)
	    if ($game_count == $number_of_regular_season_games) # was $season_team_stats{games}
	    {
		    # We're done with the regular season stats, so close the gamelog and save stats to file
		    print output_filehandle "<\/table>\n";
		    foreach (sort keys %team_list)
		    {
                print output_filehandle "<a name=RegularSeasonTotals><\/a>\n";
		    	dump_stats_summary_to_file("regular season",$_);
	    	}
		    
		    # Now get ready for the playoffs!
			if ($config_options{inventory} eq "on")
			{		    
                print output_filehandle "<a name=PlayoffInventory><\/a>\n";
                
		    	print output_filehandle "<p><h3>Playoffs Game Inventory<\/h3><table>\n";
			}		    
			
		    # clear all hashes
			%player_fgm = ();
			%player_ftm = ();
			%player_fta = ();
			%player_fgm3 = ();
			%player_fga3 = ();
			%player_pf = ();
			%player_pts = ();
			%player_games_played = ();
			%player_first_names = ();
			%player_last_names = ();
			%player_min = ();
			%player_fga = ();
			%player_reb = ();
			%player_ast = ();
			
			# Clear hashes
			foreach (keys %current_game_counters)
		 	{
			 	$current_game_counters{$_} = 0;
			}

			%season_stat_counters_fgm = ();
			%season_stat_counters_ftm = ();
			%season_stat_counters_fta = ();
			%season_stat_counters_fgm3 = ();
			%season_stat_counters_fga3 = ();
			%season_stat_counters_pf = ();
			%season_stat_counters_pts = ();
			%season_stat_counters_games_played = ();
			%season_stat_counters_min = ();
			%season_stat_counters_fga = ();
			%season_stat_counters_reb = ();
			%season_stat_counters_team_reb = ();
			%season_stat_counters_ast = ();
						
			%season_team_fgm = ();
			%season_team_ftm = ();
			%season_team_fta = ();
			%season_team_fgm3 = ();
			%season_team_fga3 = ();
			%season_team_pf = ();
			%season_team_pts = ();
			%season_team_games_played = ();
			%season_team_min = ();
			%season_team_fga = ();
			%season_team_reb = ();
			%season_team_team_reb = ();
			%season_team_ast = ();
			
			if ($config_options{inventory} eq "on")
			{
				print output_filehandle $inventory_header;
			}
		}
		
		$game_count++;
		
	}	
    elsif ($line =~ /^version/)
    {
        # ignore
    }
    elsif ($line =~ /^issue/)
    {
        $save_this_line = $line;

        # split the line
        @this_line_array = parse_csv_line($line);
        
        $note_type = $this_line_array[1];
        
	    if ($note_type eq "regular")
	    {
    	    $the_note = $regular_season_issue;
        }    	    
	    if ($note_type eq "playoffs")
	    {
    	    $the_note = $playoff_issue;
        }    	    
    	    
		# grab everything except for "issue,regular(or playoff)" and remove any CR/LF
		$complete_note = substr($save_this_line,(7 + length($this_line_array[1])));
		chomp($complete_note);    
		
#		print ("This is $this_line_array[1] $complete_note\n");

        if (length($the_note) > 0)
        {
	        # Add to output
	        $the_note = $the_note . " ... " . $complete_note;
    	}
    	else
    	{
	    	# First note for this game
            $the_note = $complete_note;
    	}

	    if ($note_type eq "regular")
	    {
    	    $regular_season_issue = $the_note;
#    	    print $regular_season_issue;
        }    	    
	    if ($note_type eq "playoffs")
	    {
    	    $playoff_issue = $the_note;
#    	    print $playoff_issue;
        }    	    
    	
    }
    elsif ($line =~ /^sources/)
    {
        # split the line
        @this_line_array = parse_csv_line($line);
        
	    $game_sources = $this_line_array[1];
	}	
    elsif ($line =~ /^info/)
    {
        # split the line
        @this_line_array = parse_csv_line($line);
        
        # IMPORTANT
        # We make the assumption that the rteam/hteam is declared in the boxtop file first.
        
		if ($this_line_array[1] eq "rteam")
        {
            $road_team_name = $this_line_array[2];
	        $team_string = $this_line_array[2];
        }
        elsif ($this_line_array[1] eq "hteam")
        {
	        $home_team_name = $this_line_array[2];
	        $team_string = $this_line_array[2];
        }
        # Also grab some game info so we can track what we are missing
        elsif ($this_line_array[1] eq "date")
		{
	        $game_date = $this_line_array[2];
		}        
		elsif ($this_line_array[1] eq "title")
		{
	        $game_title = $this_line_array[2];
		}        
		elsif ($this_line_array[1] eq "arena")
		{
	        $game_arena = $this_line_array[2];
		}        
		elsif ($this_line_array[1] eq "attendance")
		{
	        $game_attendance = $this_line_array[2];
		}        
		elsif ($this_line_array[1] eq "starttime")
		{
	        $game_starttime = $this_line_array[2];
		}        
		elsif ($this_line_array[1] eq "ref")
		{
			if ($this_line_array[2] ne "")
	        {
		        $game_ref_count++;
	    	}
		}        
        
    }
    elsif ($line =~ /^coach/)
    {
        # ignore
    }
    elsif ($line =~ /^stat/)
    {
        # split the line and add to hash
        @this_line_array = parse_csv_line($line);
        
        if ($this_line_array[1] eq "rteam")
        {
        	$tm_str = $road_team_name;
    	}
    	else
        {
        	$tm_str = $home_team_name;
    	}
        
        # Check if this team is included in the list of teams we want to collect stats for
        if (exists($team_list{$tm_str}))
        {
	        # This player plays for the team we care about. Grab the stats.
			# stat,rteam,player,ramsefr01,Frank,Ramsey,,3,,5,6,,,11,,,,5,,,,
# stat,rteam|hteam,player,ID,FIRSTNAME,LASTNAME,MIN,FGM,FGA,FTM,FTA,3FGM,3FGA,PTS,OREB,REB,AST,PF,BLOCKS,TURNOVERS,STEALS,TECHNICALFOUL
# 0    1           2      3  4         5        6   7   8   9   10  11   12   13  14   15  16  17 18     19        20     21		
			$player_id = $this_line_array[3] . "-" . $tm_str;
			
			if (($this_line_array[6] eq "") || ($this_line_array[6] > 0)) # cover cases where player minutes are explictly listed as "zero"
            {
	            if (exists($player_games_played{$player_id}))
	            {
		            $player_games_played{$player_id}++;
		            $player_fgm{$player_id} += $this_line_array[7];
		            $player_ftm{$player_id} += $this_line_array[9];
		            $player_fta{$player_id} += $this_line_array[10];
		            $player_fgm3{$player_id} += $this_line_array[11];
		            $player_fga3{$player_id} += $this_line_array[12];
		            $player_pts{$player_id} += $this_line_array[13];
		            $player_pf{$player_id} += $this_line_array[17];
		            
		            $player_min{$player_id} += $this_line_array[6];
		            $player_fga{$player_id} += $this_line_array[8];
		            $player_reb{$player_id} += $this_line_array[15];
		            $player_ast{$player_id} += $this_line_array[16];
	        	}
	        	else # create new entries for this player
	        	{
		        	# Only grab name one time
		        	$player_first_names{$player_id} = $this_line_array[4];
		        	$player_last_names{$player_id} = $this_line_array[5];
	        	
		            $player_games_played{$player_id} = 1;
		            $player_fgm{$player_id} = $this_line_array[7];
		            $player_ftm{$player_id} = $this_line_array[9];
		            $player_fta{$player_id} = $this_line_array[10];
		            $player_fgm3{$player_id} = $this_line_array[11];
		            $player_fga3{$player_id} = $this_line_array[12];
		            $player_pts{$player_id} = $this_line_array[13];
		            $player_pf{$player_id} = $this_line_array[17];
		            
		            $player_min{$player_id} = $this_line_array[6];
		            $player_fga{$player_id} = $this_line_array[8];
		            $player_reb{$player_id} = $this_line_array[15];
		            $player_ast{$player_id} = $this_line_array[16];
	        	}
    		}
    	
    		# TBD - this probably needs to be separate road and home hashes in order to accurately reflect each team, 
    		# but for now let's keep it this way and treat a stat as complete for both or neither
    		
        	$current_game_counters{games}++;
	        if ($this_line_array[6] ne "")
	        {
		        $current_game_counters{minutes}++;
	        }
	        if ($this_line_array[7] ne "")
	        {
		        $current_game_counters{fgm}++;
	        }
	        if ($this_line_array[8] ne "")
	        {
		        $current_game_counters{fga}++;
	        }
	        if ($this_line_array[9] ne "")
	        {
		        $current_game_counters{ftm}++;
	        }
	        if ($this_line_array[10] ne "")
	        {
		        $current_game_counters{fta}++;
	        }
	        if ($this_line_array[11] ne "")
	        {
		        $current_game_counters{fgm3}++;
	        }
	        if ($this_line_array[12] ne "")
	        {
		        $current_game_counters{fga3}++;
	        }
	        if ($this_line_array[13] ne "")
	        {
		        $current_game_counters{pts}++;
	        }
	        if ($this_line_array[17] ne "")
	        {
		        $current_game_counters{pf}++;
	        }
	        if ($this_line_array[15] ne "")
	        {
		        $current_game_counters{reb}++;
	        }
	        if ($this_line_array[16] ne "")
	        {
		        $current_game_counters{ast}++;
	        }
        }
    }
    elsif ($line =~ /^tstat/)
    {
        # split the line and add to hash
        @this_line_array = parse_csv_line($line);
        
        if ($this_line_array[1] eq "rteam")
        {
        	$tm_str = $road_team_name;
    	}
    	else
        {
        	$tm_str = $home_team_name;
    	}
    	
        if (exists($team_list{$tm_str})) # ($this_line_array[1] eq $team_string)
        {
	        # This is the team we care about. Grab the stats.
			# tstat,rteam,,44,,27,38,,,115,,,,34,,,,,
# tstat,rteam|hteam,MIN,FGM,FGA,FTM,FTA,FG3M,FG3A,PTS,OREB,REB,AST,PF,BLOCKS,TURNOVERS,STEALS,TEAMREBOUNDS,TECHNICALFOUL
# 0     1           2   3   4   5   6   7    8    9   10   11  12  13 14     15        16     17           18
			$season_team_games_played{$tm_str}++;
			
			# Note, perl is smart enough to do the math correctly (i.e. add zero) if
			# the string is empty. But since we want to count the number of times 
			# that a particular stat is available, we might as well check.
			if ($this_line_array[3] ne "")
			{
				$season_team_fgm{$tm_str} += $this_line_array[3];
			}
			
			if ($this_line_array[5] ne "")
			{
				$season_team_ftm{$tm_str} += $this_line_array[5];
			}
		
			if ($this_line_array[6] ne "")
			{
				$season_team_fta{$tm_str} += $this_line_array[6];
			}
			
			if ($this_line_array[7] ne "")
			{
				$season_team_fgm3{$tm_str} += $this_line_array[7];
			}
			
			if ($this_line_array[8] ne "")
			{
				$season_team_fga3{$tm_str} += $this_line_array[8];
			}
			
			if ($this_line_array[13] ne "")
			{
				$season_team_pf{$tm_str} += $this_line_array[13];
			}
			
			if ($this_line_array[9] ne "")
			{
				$season_team_pts{$tm_str} += $this_line_array[9];
			}
			
			if ($this_line_array[2] ne "")
			{
				$season_team_min{$tm_str} += $this_line_array[2];
			}
			
			if ($this_line_array[4] ne "")
			{
				$season_team_fga{$tm_str} += $this_line_array[4];
			}
			
			if ($this_line_array[11] ne "")
			{
				$season_team_reb{$tm_str} += $this_line_array[11];
			}
			
			if ($this_line_array[12] ne "")
			{
				$season_team_ast{$tm_str} += $this_line_array[12];
			}
			
			if ($this_line_array[17] ne "")
			{
				$season_team_team_reb{$tm_str} += $this_line_array[17];
				
				# Special case where we can increment the season stat counters right here
				$season_stat_counters_team_reb{$tm_str}++;
			}
        }
    }
    elsif ($line =~ /^linescore/)
    {
        # ignore
    }   


} # end of main loop

# TBD - get rid of this duplicate code

# We're finished with the LAST box score, so determine if we need to increment our team stat counters
# Note that the "games" field is set equal to the number of players in this game; the other values
# will be <= that number.

# Log the last game	    
if ($config_options{inventory} eq "on")
{
	gamelog_to_file();	    
}

# Process all of the data (if team did not make playoffs) or just the playoff data
# print "game_count=$game_count, total games=$number_of_regular_season_games\n";
if ($game_count <= $number_of_regular_season_games)
{
    print output_filehandle "<\/table>\n";
    foreach (sort keys %team_list)
	{
        print output_filehandle "<a name=RegularSeasonTotals><\/a>\n";
		dump_stats_summary_to_file("regular season",$_);
	}
    if ($game_count < $number_of_regular_season_games)
    {
	    print "Warning only $game_count games processed (Regular Season = $number_of_regular_season_games games)\n";
	}
}
else
{
    print output_filehandle "<\/table>\n";
    foreach (sort keys %playoff_team_list)
	{
        print output_filehandle "<a name=PlayoffSeasonTotals><\/a>\n";
		dump_stats_summary_to_file("playoff",$_);
	}
}

if ($config_options{inventory} eq "on")
{
	print output_filehandle "<p><b>Abbreviations for Sources</b>:<br>";
	print output_filehandle "BG - Boston Globe<br>";
	print output_filehandle "BH - Boston Herald<br>";
	print output_filehandle "BRA - Boston Record-American<br>";
	print output_filehandle "BR.com - Basketball-Reference.com<br>";
	print output_filehandle "CY - Boston Celtics Yearbook<br>";
	print output_filehandle "G7 - Woten, Bill. <i>Game 7: Inside the NBA�s Ultimate Showdown.</i> Self-published, 2007.<br>";
	print output_filehandle "NYT - New York Times<br>";
	print output_filehandle "PI - Philadelphia Inquirer<br>";
	print output_filehandle "SB - Sullivan, George. <i>The Picture History of the Boston Celtics.</i> Indianapolis/New York: Bobbs-Merrill Company, 1981.<br>";
	print output_filehandle "SHJ - Syracuse Herald-Journal<br>";
	print output_filehandle "TSN - The Sporting News<br>";
	print output_filehandle "W - NBA Finals Boxscore collection, <a href=\"http://webuns.chez-alice.fr/home.htm\">http://webuns.chez-alice.fr/home.htm</a> (referenced by <a href=\"http://www.apbr.org\">APBR.org</a>)<br>";
}

add_footer();

close (output_filenandle);

print "File $output_filename created.\n";
