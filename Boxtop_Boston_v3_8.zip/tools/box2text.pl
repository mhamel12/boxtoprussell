# ===============================================================
# 
# box2text.pl
#
# (c) 2010-2011 Michael Hamel
#
# This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License. To view a copy of this license, visit # http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.
#
# Version history
# 12/28/2010  1.0  MH  Initial version
# 03/05/2011  1.1  MH  Team rebounds = REB + TEAMREBOUNDS
# 04/02/2011  1.2  MH  Fixed bug in how start of file was handled, which caused first box score to be skipped
# 05/21/2011  1.3  MH  Added support for multiple game note fields
# 11/26/2011  1.4  MH  Partial sync up with box2html.pl (three pointers, full stats)
#
# ===============================================================


#! usr/bin/perl
use Getopt::Std;

# store data split in these hashes
my %info;

# store data unsplit in these hashes, indexed by hteam and rteam
my %coaches;
my %team_stats;
my %linescores;

# store data unsplit in these hashes, indexed by player id
my %road_player_stats;
my %home_player_stats;

my $index_count = 1;
my $game_count = 1;

# init to defaults
my %config_options = (
	threeptfg => off,
);


# ===============================================================

sub usage
{
    print "Convert a boxtop-format file into a single text file suitable for pasting into a word processor program.\n";
    print "\n";
    print "\nUSAGE:\n";
    print " box2text.pl [-i inputfilename] [-o outputfilename] \n";
    print "             [-g three on|off]\n";
    print " Default filenames are input.csv and output.txt unless specified.\n";
    print " Three pointers are OFF by default.\n";
}
# end of sub usage()

# ===============================================================

# ===============================================================
# 
# parse_csv_line()
#
# Parses one line of a csv file and fills an array to return to caller.
#
# Input:
#
# Output:
#  Array that contains each element of the csv line.
#
# ===============================================================
sub parse_csv_line(@)
{
    ($line) = @_;

        # Note: If we don't declare this here, we end up re-using previously
    #       declared variable on our next trip through here!
        my @csv_elements;

        # trick - add a comma at the end of the line in place of the CR
        # makes searching easier...
        chomp($line);
        $line = join(",",$line,"");
    
        while ((my $next_comma = index($line,",")) >= 0)
        {
            # Grab next column header.
            push @csv_elements, substr($line,0,$next_comma);

            $line = substr($line,($next_comma+1),length($line));
        }
    
        return(@csv_elements);
}
# end of sub parse_csv_line()

# ===============================================================

sub add_footer()
{
	print output_filehandle "<p>This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License.<br>To view a copy of this license, visit <a href=\"http:\/\/creativecommons.org\/licenses\/by-nc-sa\/3.0\/\">http:\/\/creativecommons.org\/licenses\/by-nc-sa\/3.0\/<\/a>\n";
	print output_filehandle "<p>Web page created using box2html.pl based on boxtop format data, (c) 2010-2011 Michael Hamel.\n";
}
# end of sub add_footer()

# ===============================================================

sub dump_textdata_to_file()
{
#   print(%info);
#   print(%coaches);
#   print(%team_stats);
#   print(%linescores);
#   print(%road_player_stats);
#   print(%home_player_stats);

    print output_filehandle "Game $game_count\n";
    $game_count++;
    print output_filehandle "$info{rteam} vs. $info{hteam}\n";
    print output_filehandle "$info{title}\n$info{dayofweek} $info{date} at $info{arena}\n$info{city}, $info{state}, $info{country}\n";

	# stats go here in simple .csv tables...
    print output_filehandle  "\n$info{rteam}\n\n";
    
	# modern stats
	if($config_options{threeptfg} eq "on")
	{
		print output_filehandle ",MIN,FGM,FGA,FTM,FTA,3FGM,3FGA,OREB,REB,AST,STL,BLK,TOV,PF,PTS\n";
	}
	else
	{	
		print output_filehandle ",MIN,FGM,FGA,FTM,FTA,OREB,REB,AST,STL,BLK,TOV,PF,PTS\n";
	}    

	foreach $value (sort values %road_player_stats)
    {
#       print $value;
        @stats_line = parse_csv_line($value);
        
		# 0    1           2      3  4         5        6   7   8   9   10  11   12   13  14   15  16  17 18     19        20     21
        # stat,rteam|hteam,player,ID,FIRSTNAME,LASTNAME,MIN,FGM,FGA,FTM,FTA,3FGM,3FGA,PTS,OREB,REB,AST,PF,BLOCKS,TURNOVERS,STEALS,TECHNICALFOUL
        
        #                        First Name      Last Name      MIN            FGM            FGA           
        print output_filehandle "$stats_line[4] $stats_line[5],$stats_line[6],$stats_line[7],$stats_line[8],";
        
        if($config_options{threeptfg} eq "on")
        {
	        #                        3FGM            3FGA           
    	    print output_filehandle "$stats_line[11],$stats_line[12],";
    	}
    	
        #                       FTM             FTA             OREB             REB             AST             STL             BLK             TOV             PF              PTS
        print output_filehandle "$stats_line[9],$stats_line[10],$stats_line[14],$stats_line[15],$stats_line[16],$stats_line[20],$stats_line[18],$stats_line[19],$stats_line[17],$stats_line[13]\n";
    }
    $value = $team_stats{rteam};
    @stats_line = parse_csv_line($value);

	# 0     1           2   3   4   5   6   7    8    9   10   11  12  13 14     15        16     17           18
    # tstat,rteam|hteam,MIN,FGM,FGA,FTM,FTA,FG3M,FG3A,PTS,OREB,REB,AST,PF,BLOCKS,TURNOVERS,STEALS,TEAMREBOUNDS,TECHNICALFOUL
          
    # Add rebounds + teamrebounds together to match usual boxscore format
    # If no rebounds available, then print a blank
    if ($stats_line[11] ne "")
    {
		$rebounds = $stats_line[11] + $stats_line[17];
	}
	else
	{
		$rebounds = "";
	}
	
    #                                FGM            FGA           
    print output_filehandle "Totals,,$stats_line[3],$stats_line[4],";
    
    if($config_options{threeptfg} eq "on")
    {
        #                        3FGM            3FGA           
	    print output_filehandle "$stats_line[7],$stats_line[8],";
	}
	
    #                       FTM             FTA            OREB            REB             AST             STL             BLK             TOV             PF              PTS
    print output_filehandle "$stats_line[5],$stats_line[6],$stats_line[10],$stats_line[11],$stats_line[12],$stats_line[16],$stats_line[14],$stats_line[15],$stats_line[13],$stats_line[9]\n";
        	
    if ($stats_line[17] ne "") { print output_filehandle "Team Rebounds: $stats_line[17]\n"; }
    
    
	# modern stats
	if($config_options{threeptfg} eq "on")
	{
		print output_filehandle ",MIN,FGM,FGA,FTM,FTA,3FGM,3FGA,OREB,REB,AST,STL,BLK,TOV,PF,PTS\n";
	}
	else
	{	
		print output_filehandle ",MIN,FGM,FGA,FTM,FTA,OREB,REB,AST,STL,BLK,TOV,PF,PTS\n";
	}    
	
    foreach $value (sort values %home_player_stats)
    {
#       print $value;
        @stats_line = parse_csv_line($value);
		# 0    1           2      3  4         5        6   7   8   9   10  11   12   13  14   15  16  17 18     19        20     21
        # stat,rteam|hteam,player,ID,FIRSTNAME,LASTNAME,MIN,FGM,FGA,FTM,FTA,3FGM,3FGA,PTS,OREB,REB,AST,PF,BLOCKS,TURNOVERS,STEALS,TECHNICALFOUL
        
        #                        First Name      Last Name      MIN            FGM            FGA           
        print output_filehandle "$stats_line[4] $stats_line[5],$stats_line[6],$stats_line[7],$stats_line[8],";
        
        if($config_options{threeptfg} eq "on")
        {
	        #                        3FGM            3FGA           
    	    print output_filehandle "$stats_line[11],$stats_line[12],";
    	}
    	
        #                       FTM             FTA             OREB             REB             AST             STL             BLK             TOV             PF              PTS
        print output_filehandle "$stats_line[9],$stats_line[10],$stats_line[14],$stats_line[15],$stats_line[16],$stats_line[20],$stats_line[18],$stats_line[19],$stats_line[17],$stats_line[13]\n";
    }
    $value = $team_stats{hteam};
    @stats_line = parse_csv_line($value);

    if ($stats_line[11] ne "")
    {
		$rebounds = $stats_line[11] + $stats_line[17];
	}
	else
	{
		$rebounds = "";
	}
	
    #                                FGM            FGA           
    print output_filehandle "Totals,,$stats_line[3],$stats_line[4],";
    
    if($config_options{threeptfg} eq "on")
    {
        #                        3FGM            3FGA           
	    print output_filehandle "$stats_line[7],$stats_line[8],";
	}
	
    #                       FTM             FTA            OREB            REB             AST             STL             BLK             TOV             PF              PTS
    print output_filehandle "$stats_line[5],$stats_line[6],$stats_line[10],$stats_line[11],$stats_line[12],$stats_line[16],$stats_line[14],$stats_line[15],$stats_line[13],$stats_line[9]\n";
        	

    if ($stats_line[17] ne "") { print output_filehandle "Team Rebounds: $stats_line[17]\n"; }
    
    # linescores in a table
    @road_linescore = parse_csv_line($linescores{rteam});
    @home_linescore = parse_csv_line($linescores{hteam});
    $column_count = $#road_linescore - 1; # assume both the same length
    
    # extra column in first line to provide space for team name
    print output_filehandle "\n,";
    for ($cc=1; $cc<$column_count-1; $cc++)
    {
	    if ($cc==5)
	    {
		    $period = "OT";
		}
	    elsif ($cc>5)
	    {
		    $period = "O".($cc-4);
		}
		else
		{
			$period = $cc;
		}
        print output_filehandle "$period,";
    }
    print output_filehandle "F\n";

    print output_filehandle "$info{rteam},";
    for ($cc=2; $cc<$column_count; $cc++)
    {
        print output_filehandle "$road_linescore[$cc],";
    }
    print output_filehandle "$road_linescore[$column_count+1]\n";
    
    print output_filehandle "$info{hteam},";
    for ($cc=2; $cc<$column_count; $cc++)
    {
        print output_filehandle "$home_linescore[$cc],";
    }
    print output_filehandle "$home_linescore[$column_count+1]\n";

    @road_coach_line = parse_csv_line($coaches{rteam});
    @home_coach_line = parse_csv_line($coaches{hteam});

    print output_filehandle "\nHead Coaches: ";
    print output_filehandle "$info{rteam} - $road_coach_line[3] $road_coach_line[4]";
    print output_filehandle ", ";
    print output_filehandle "$info{hteam} - $home_coach_line[3] $home_coach_line[4]";
    print output_filehandle "\n\n";
        
    # Omit the following fields if they are empty
    if ($info{note} ne "") { print output_filehandle "Game Notes: $info{note}\n\n"; }
    if ($info{prelim} ne "") { print output_filehandle "Preliminary Game: $info{prelim}\n\n"; }
    if ($info{event} ne "") { print output_filehandle "Special Event: $info{event}\n\n"; }
    if ($info{attendance} ne "") { print output_filehandle "Attendance: $info{attendance}\n"; }
    if ($info{ref1} ne "") { print output_filehandle "Referees: $info{ref1}, $info{ref2}\n"; }
    if ($info{starttime} ne "") { print output_filehandle "Start Time: $info{starttime} $info{timezone}\n"; }
    if ($info{radio} ne "") { print output_filehandle "Boston Radio: $info{radio}\n"; }
    if ($info{tv} ne "") { print output_filehandle "Boston TV: $info{tv}\n"; }

    print output_filehandle "\n==============================\n";

} # end of sub dump_textdata_to_file()

# ===============================================================


$start_of_boxscore = "gamebxt";

# default filenames
$input_filename = "input.csv";
$output_filename = "output.txt";

getopts('i:o:h:g:',\%cli_opt);


if (exists ($cli_opt{"i"}))
{
    $input_filename = $cli_opt{"i"};
}

if (exists ($cli_opt{"o"}))
{
    $output_filename = $cli_opt{"o"};
}

if (exists ($cli_opt{"g"}))
{
	$config_options{threeptfg} = lc($cli_opt{"g"});
}

if (exists ($cli_opt{"h"}))
{
	usage();
	exit;
}

# open for reading
if (!open(input_filehandle, "$input_filename")) 
{
        die "Can't open input file $input_filename\n";
}

# open for writing, creating if needed
if (!open(output_filehandle, ">$output_filename")) 
{
        close(input_filehandle);
        die "Can't open output file $output_filename\n";
}

my $ref_count = 1;
my $first_gamebxt_read = "no";

while ($line = <input_filehandle>)
{
    # read until we read a "gamebxt" which tells us to loop back around to the next boxscore
    # but skip everything until after we read the first one
    if ($first_gamebxt_read eq "no")
    {
	    if ($line =~ /^$start_of_boxscore/)
	    {
		    # flip the flag, but ignore this line
		    $first_gamebxt_read = "yes";
		}
		# else just skip the line
	}			  
    elsif ($line =~ /^$start_of_boxscore/)
    {
        dump_textdata_to_file();
        $ref_count = 1;
        
        # clear all hashes
        %info = ();
        %coaches = ();
        %team_stats = ();
        %linescores = ();
        %road_player_stats = ();
        %home_player_stats = ();
    }
    elsif ($line =~ /^version/)
    {
        # ignore
    }
    elsif ($line =~ /^info/)
    {
        # split the line and add to hash, but save a copy of the original line because parse_csv_line() destroys it
        $save_this_line = $line;
        @this_line_array = parse_csv_line($line);
        
        # special case for refs
        if ($this_line_array[1] eq "ref")
        {
            $info{$this_line_array[1].$ref_count} = $this_line_array[2];
            $ref_count++;
        }
        # special case for game notes (concatenate)
        elsif (($this_line_array[1] eq "note") ||
    	   	   ($this_line_array[1] eq "event") ||
    	       ($this_line_array[1] eq "prelim"))
    	{
	        # the following works, but we want to insert '...' only in between entries, not after last entry
    	    # it also does not support commas inside the note
#	        $info{note} = $info{note} . $this_line_array[2];

			# grab everything except for "info,note," and remove any CR/LF
			# note, event, prelim are all different lengths so we need to use correct width
			$complete_note = substr($save_this_line,(6 + length($this_line_array[1])));
			chomp($complete_note);    
		
#			print ("This is $this_line_array[1] $complete_note\n");

	        if (exists($info{$this_line_array[1]}))
        	{
	        	# Add to output
	        	$info{$this_line_array[1]} = $info{$this_line_array[1]} . " ... " . $complete_note;
    		}
    		else
    		{
		    	# First note for this game
    	        $info{$this_line_array[1]} = $complete_note;
	    	}
		}
    	else
    	{
	        $info{$this_line_array[1]} = $this_line_array[2];
	    }
	}
    elsif ($line =~ /^coach/)
    {
        # split the line and add to hash
        $copyline = $line;
        @this_line_array = parse_csv_line($line);
        $coaches{$this_line_array[1]} = $copyline;
    }
    elsif ($line =~ /^stat/)
    {
        # split the line and add to hash
        $copyline = $line;
        @this_line_array = parse_csv_line($line);
        if ($this_line_array[1] eq "rteam")
        {
            $road_player_stats{$this_line_array[3]} = $copyline;
        }
        else
        {
            $home_player_stats{$this_line_array[3]} = $copyline;
        }
    }
    elsif ($line =~ /^tstat/)
    {
        # split the line and add to hash
        $copyline = $line;
        @this_line_array = parse_csv_line($line);
        $team_stats{$this_line_array[1]} = $copyline;
    }
    elsif ($line =~ /^linescore/)
    {
        # split the line and add to hash
        $copyline = $line;
        @this_line_array = parse_csv_line($line);
        $linescores{$this_line_array[1]} = $copyline;
    }   


} # end of main loop


dump_textdata_to_file();

close (output_filenandle);

print "File $output_filename created.\n";
